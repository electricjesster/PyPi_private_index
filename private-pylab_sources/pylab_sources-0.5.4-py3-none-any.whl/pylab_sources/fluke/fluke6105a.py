from __future__ import annotations

from typing import Literal, Mapping, Sequence, Tuple, Union

from colorama import Fore, Style
from colorama import init as colorama_init
from .scpi import SCPIInstrument

colorama_init(strip=False, convert=False)

RESET = Style.RESET_ALL
_CYAN = getattr(Fore, "CYAN", "")
_LIGHTBLACK = getattr(Fore, "LIGHTBLACK_EX", "")
BCYAN = Style.BRIGHT + _CYAN
NGREY = _LIGHTBLACK


def _print_verbose(tag: str, msg: str) -> None:
    print(f"\t  {BCYAN}[{tag}]{RESET} {NGREY}{msg}{RESET}")

PhaseName = Literal["P1", "P2", "P3", "P4"]
def _phase_index(phase: Union[PhaseName, int]) -> int:
    if isinstance(phase, int):
        if not (1 <= phase <= 4):
            raise ValueError("phase int must be 1..4")
        return phase
    m = {"P1":1,"P2":2,"P3":3,"P4":4}
    if phase not in m:
        raise ValueError("phase must be 'P1'|'P2'|'P3'|'P4' or int 1..4")
    return m[phase]

def _pick_current_range(amps: float) -> tuple[float,float,str]:
    table = [
        (0.05, 0.5, "UPPER"),
        (0.1, 1.0, "UPPER"),
        (0.2, 2.0, "UPPER"),
        (0.5, 5.0, "UPPER"),
        (1.0, 10.0, "UPPER"),
        (2.0, 21.0, "LOWER"),
        (5.0, 50.0, "LOWER"),
        (8.0, 80.0, "LOWER"),
    ]
    for lo, hi, term in table:
        if amps <= hi * 1.001:
            return lo, hi, term
    raise ValueError(f"Requested {amps} A exceeds 80 A range")

class Fluke6105A(SCPIInstrument):
    def __init__(self, transport):
        super().__init__(transport)
        self._src_verbose = False
        self._amp_cache = {
    'VOLT': {
        1: None, 2: None, 3: None, 4: None}, 'CURR': {
            1: None, 2: None, 3: None, 4: None}}
        self._phase_cache = {
    'VOLT': {
        1: None, 2: None, 3: None, 4: None}, 'CURR': {
            1: None, 2: None, 3: None, 4: None}}

    @classmethod
    def open(cls, resource_name: str, *, verbose: bool = False, **kwargs):
        inst = super().open(resource_name, verbose=verbose, **kwargs)
        inst._src_verbose = bool(verbose)
        return inst
    def output_enable(self, on: bool=True) -> None:
        try:
            self.write(f"OUTP:STAT {'ON' if on else 'OFF'}")
        except Exception:
            pass
    def set_frequency(self, f_hz: float) -> None: 
        if self._src_verbose:
            _print_verbose("fluke", f"Setting frequency to {f_hz:.9g} Hz")
        self.write(f"SOUR:FREQ {f_hz:.9g}")
    def get_frequency(self) -> float: return float(self.query("SOUR:FREQ?"))
    def set_line_lock(
        self, enabled: bool) -> None: self.write(f"SOUR:FREQ:LINE {1 if enabled else 0}")
    def is_line_locked(
        self) -> bool: return self.query("SOUR:FREQ:LOCK?") == "1"

    def set_angle_units(self, units: str = "DEG") -> None:
        u = units.upper()
        if u not in ("DEG","RAD"):
            raise ValueError("units must be 'DEG' or 'RAD'")
        self.write(f"UNIT:ANGLe {u}")
    def set_mhar_units(self, kind: str, units: str) -> None:
        k = kind.upper()
        if k not in ("VOLT","CURR"):
            raise ValueError("kind must be VOLT or CURR")
        u = units.upper()
        if u not in ("ABS","PRMS"):
            raise ValueError("units must be ABS or PRMS")
        self.write(f"UNIT:MHAR:{k} {u}")
    def set_dip_time_units(self, units: str = "SEC") -> None:
        u = units.upper()
        if u not in ("SEC","CYCL"):
            raise ValueError("units must be 'SEC' or 'CYCL'")
        self.write(f"UNIT:DIP:TIME {u}")

    def enable_voltage(self, phase: Union[PhaseName,int], on: bool) -> None:
        p = _phase_index(phase)
        self.write(f"SOUR:PHAS{p}:VOLT:STAT {1 if on else 0}")
    def voltage_enabled(self, phase: Union[PhaseName,int]) -> bool:
        p = _phase_index(phase)
        return self.query(f"SOUR:PHAS{p}:VOLT:STAT?") == "1"
    def enable_current(self, phase: Union[PhaseName,int], on: bool) -> None:
        p = _phase_index(phase)
        self.write(f"SOUR:PHAS{p}:CURR:STAT {1 if on else 0}")
    def current_enabled(self, phase: Union[PhaseName,int]) -> bool:
        p = _phase_index(phase)
        return self.query(f"SOUR:PHAS{p}:CURR:STAT?") == "1"

    def set_voltage_phase(
        self, phase: Union[PhaseName,int], deg: float) -> None:
        p = _phase_index(phase)
        if self._src_verbose:
            _print_verbose("fluke", f"P{p} voltage phase -> {deg:.9g} deg")
        amp = self._amp_cache['VOLT'].get(p) or 120.0
        self.harm_set(p, 1, float(amp), float(deg), "VOLT")
        self._phase_cache['VOLT'][p] = float(deg)
    def get_voltage_phase(self, phase: Union[PhaseName,int]) -> float:
        p = _phase_index(phase)
        cached = self._phase_cache['VOLT'].get(p)
        if cached is not None:
            return float(cached)
        try:
            a, ph = self.harm_get(p, 1, "VOLT")
            return ph
        except Exception:
            return 0.0

    def set_current_phase(
        self, phase: Union[PhaseName,int], deg: float) -> None:
        p = _phase_index(phase)
        if self._src_verbose:
            _print_verbose("fluke",
     f"P{p} current phase request -> {deg:.9g} deg")
        amp = self._amp_cache['CURR'].get(p) or 5.0
        rel = deg - self.get_voltage_phase(p)
        self.harm_set(p, 1, float(amp), float(rel), "CURR")
        self._phase_cache['CURR'][p] = float(deg)
        if self._src_verbose:
            _print_verbose(
    "fluke<-",
    f"P{p} current phase programmed as {
        rel:.9g} deg relative (absolute {
            deg:.9g} deg)")
    def get_current_phase(self, phase: Union[PhaseName,int]) -> float:
        p = _phase_index(phase)
        cached = self._phase_cache['CURR'].get(p)
        if cached is not None:
            return float(cached)
        try:
            a, ph = self.harm_get(p, 1, "CURR")
            return ph
        except Exception:
            return 0.0

    def mhar_enable(
        self, phase: Union[PhaseName,int], on: bool, kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        self.write(f"SOUR:PHAS{p}:{k}:MHAR:STAT {1 if on else 0}")
    def mhar_cle(self, phase: Union[PhaseName,int], kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        self.write(f"SOUR:PHAS{p}:{k}:MHAR:CLE")
    def mhar_ampl(self, phase: Union[PhaseName,int],
                  value: float, kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        self.write(f"SOUR:PHAS{p}:{k}:MHAR:AMPL {value:.9g}")
    def mhar_ampl_q(
        self, phase: Union[PhaseName,int], kind: str="VOLT") -> float:
        p = _phase_index(phase)
        k = kind.upper()
        return float(self.query(f"SOUR:PHAS{p}:{k}:MHAR:AMPL?"))
    def harm_set(self, phase: Union[PhaseName,int], order: int,
                 amplitude: float, phase_deg: float, kind: str="VOLT") -> None:
        if order < 0:
            raise ValueError("order must be >= 0")
        p = _phase_index(phase)
        k = kind.upper()
        self.write(
    f"SOUR:PHAS{p}:{k}:MHAR:HARMonic{order} {
        amplitude:.9g},{
            phase_deg:.9g}")
    def harm_get(self, phase: Union[PhaseName,int],
                 order: int, kind: str="VOLT") -> Tuple[float,float]:
        if order < 0:
            raise ValueError("order must be >= 0")
        p = _phase_index(phase)
        k = kind.upper()
        resp = self.query(f"SOUR:PHAS{p}:{k}:MHAR:HARMonic{order}?")
        a, ph = resp.split(",")
        return float(a), float(ph)
    def harm_get_phase(self, phase, order: int, kind="VOLT") -> float:
        p = _phase_index(phase)
        k = kind.upper()
        return float(self.query(
            f"SOUR:PHAS{p}:{k}:MHAR:HARMonic{order}:PANGle?"))

    def set_voltage(
        self, phase: Union[PhaseName,int], volts_rms: float) -> None:
        p = _phase_index(phase)
        if self._src_verbose:
            _print_verbose("fluke",
     f"P{p} voltage amplitude -> {volts_rms:.9g} V")

        # 0) Turn the phase voltage OFF before changing range (required for
        # range change)
        try:
            self.enable_voltage(p, False)   # SOUR:PHASp:VOLT:STAT 0
        except Exception:
            pass

        # 1) Pick a proper hardware range that encloses volts_rms.
        #    For 6105A, valid ranges include: 0–23, 0–45, 0–90, 0–180, 0–360, 0–480, 0–1008 V.
        # Choose the narrowest that covers volts_rms (with a small headroom).
        target_hi = (
            23 if volts_rms <= 23 else
            45 if volts_rms <= 45 else
            90 if volts_rms <= 90 else
            180 if volts_rms <= 180 else
            360 if volts_rms <= 360 else
            480 if volts_rms <= 480 else
            1008
        )
        # SOUR:PHASp:VOLT:RANG 0,<hi>
        self.set_voltage_range(p, 0.0, float(target_hi))

        # 2) Program amplitude.
        # Use harmonics mode consistently (like your current style) and set ABS
        # units.
        self.set_mhar_units("VOLT", "ABS")                # UNIT:MHAR:VOLT ABS
        # SOUR:PHASp:VOLT:MHAR:STAT ON
        self.harm_enable(p, True, "VOLT")
        # SOUR:PHASp:VOLT:MHAR:CLE
        self.harm_clear(p, "VOLT")
        # Set the fundamental only; keep the cached phase if present
        phi = float(self._phase_cache['VOLT'].get(p) or 0.0)
        # SOUR:PHASp:VOLT:MHAR:HARM1 <Vrms>,<deg>
        self.harm_set(p, 1, float(volts_rms), phi, "VOLT")
        # (Alternatively, you could just do MHAR:AMPL <Vrms>—either approach is valid in MHAR mode)

        # 3) Turn output ON
        # SOUR:PHASp:VOLT:STAT 1
        self.enable_voltage(p, True)
        self._amp_cache['VOLT'][p] = float(volts_rms)

        # 4) Drain error queue to catch state/range problems (e.g., N-phase 33
        # V limit)
        try:
            for _ in range(8):
                err = self.query("SYST:ERR?")
                if err.startswith("0,"):
                    break
                # log or raise as appropriate for your app
        except Exception:
            pass

    def get_voltage(self, phase: Union[PhaseName,int]) -> float:
        p = _phase_index(phase)
        try:
            return float(self.query(f"SOUR:PHAS{p}:VOLT:AMPL?"))
        except Exception:
            try:
                return self.mhar_ampl_q(p, "VOLT")
            except Exception:
                return float(self._amp_cache['VOLT'].get(p) or 0.0)

    def set_current(
        self, phase: Union[PhaseName,int], amps_rms: float) -> None:
        p = _phase_index(phase)
        if self._src_verbose:
            _print_verbose("fluke",
     f"P{p} current amplitude -> {amps_rms:.9g} A")
        # 0) Turn the phase current OFF before changing range (required)
        try:
            self.enable_current(p, False)
        except Exception:
            pass

        # 1) Route terminals & ensure we’re in ordinary current mode
        lo, hi, term = _pick_current_range(float(amps_rms))
        # UPPer for ≤21A; LOWer for ≥21A
        self.write(f"SOUR:PHAS{p}:CURR:TERM:ROUT {term}")
        # ensure not in V/I equivalence
        self.write(f"SOUR:PHAS{p}:CURR:EQU:STAT OFF")
        # (Optional) assert we’re not in VOLTage mode on current ranges:
        try:
            unit = self.query(f"SOUR:PHAS{p}:CURR:RANG:UNIT?")
            if unit.strip().upper() != "CURRENT":
                raise RuntimeError("Current terminals are in VOLTage mode")
        except Exception:
            pass

        # 2) Select the exact hardware range that covers amps_rms
        # SOUR:PHASx:CURR:RANG <lo>,<hi>
        self.set_current_range(p, lo, hi)

        # 3) Program amplitude in ABS units via harmonics fundamental
        self.set_mhar_units("CURR", "ABS")
        self.harm_enable(p, True, "CURR")
        self.harm_clear(p, "CURR")
        self.harm_set(p, 1, float(amps_rms), float(
            self._phase_cache['CURR'].get(p) or 0.0), "CURR")
        # (or) self.write(f"SOUR:PHAS{p}:CURR:AMPL {amps_rms:.9g}")

        # 4) Turn output ON
        self.enable_current(p, True)
        self._amp_cache['CURR'][p] = float(amps_rms)

        # 5) Drain error queue (helps catch “settings conflict” etc.)
        try:
            for _ in range(8):
                err = self.query("SYST:ERR?")
                if err.startswith("0,"):
                    break
                # log/raise if you want
        except Exception:
            pass

    def get_current(self, phase: Union[PhaseName,int]) -> float:
        p = _phase_index(phase)
        try:
            return float(self.query(f"SOUR:PHAS{p}:CURR:AMPL?"))
        except Exception:
            try:
                return self.mhar_ampl_q(p, "CURR")
            except Exception:
                return float(self._amp_cache['CURR'].get(p) or 0.0)

    def set_voltage_range(
        self, phase: Union[PhaseName,int], low_v: float, high_v: float) -> None:
        p = _phase_index(phase)
        self.write(f"SOUR:PHAS{p}:VOLT:RANG {low_v:.9g},{high_v:.9g}")
    def get_voltage_range(
        self, phase: Union[PhaseName,int]) -> tuple[float,float]:
        p = _phase_index(phase)
        lo=float(self.query(f"SOUR:PHAS{p}:VOLT:RANG? LOW"))
        hi=float(self.query(f"SOUR:PHAS{p}:VOLT:RANG? HIGH"))
        return (lo,hi)
    def set_current_range(
        self, phase: Union[PhaseName,int], low_a: float, high_a: float) -> None:
        p = _phase_index(phase)
        self.write(f"SOUR:PHAS{p}:CURR:RANG {low_a:.9g},{high_a:.9g}")
    def get_current_range(
        self, phase: Union[PhaseName,int]) -> tuple[float,float]:
        p = _phase_index(phase)
        lo=float(self.query(f"SOUR:PHAS{p}:CURR:RANG? LOW"))
        hi=float(self.query(f"SOUR:PHAS{p}:CURR:RANG? HIGH"))
        return (lo,hi)

    def harm_clear(self,
    phase: Union[PhaseName,
    int],
    kind: str="VOLT") -> None: self.mhar_cle(phase,
     kind)
    def harm_enable(self,
    phase: Union[PhaseName,
    int],
    on: bool,
    kind: str="VOLT") -> None: self.mhar_enable(phase,
    on,
     kind)
    def harm_add(self,
    phase: Union[PhaseName,
    int],
    order: int,
    percent_or_abs: float,
    phase_deg: float,
    kind: str="VOLT") -> None: self.harm_set(phase,
    order,
    percent_or_abs,
    phase_deg,
     kind)

    def set_three_phase_system(self, v_ll_rms: float, freq_hz: float,
                               sequence: str="ABC", voltage_phase_reference_deg: float=0.0) -> None:
        self.set_frequency(freq_hz)
        self.set_angle_units("DEG")
        v_ph = v_ll_rms / (3**0.5)
        seq = sequence.upper()
        if seq not in ("ABC","ACB"):
            raise ValueError("sequence must be 'ABC' or 'ACB'")
        ang = [
    voltage_phase_reference_deg+
    0.0,
    voltage_phase_reference_deg-
    120.0,
    voltage_phase_reference_deg+
    120.0] if seq=="ABC" else [
        voltage_phase_reference_deg+
        0.0,
        voltage_phase_reference_deg+
        120.0,
        voltage_phase_reference_deg-
        120.0]
        for i, a in enumerate(ang, start=1):
            self.set_voltage(i, v_ph)
            self.set_voltage_phase(i, a)

    def set_three_phase_currents(
        self,
        i_rms: float,
        current_angles_deg: Union[Mapping[Union[PhaseName,
            int], float], Sequence[float]] | None = None,
    ) -> None:
        """Program 3φ currents with explicit absolute phase angles."""
        angles: dict[int, float] = {1: 0.0, 2: 0.0, 3: 0.0}

        if current_angles_deg is not None:
            if isinstance(current_angles_deg, dict):
                for key, val in current_angles_deg.items():
                    idx = _phase_index(key)
                    if idx > 3:
                        continue
                    angles[idx] = float(val)
            else:
                seq = list(current_angles_deg)
                if len(seq) != 3:
                    raise ValueError(
                        "current_angles_deg iterable must contain exactly three angles")
                for idx, val in enumerate(seq, start=1):
                    angles[idx] = float(val)

        self.set_angle_units("DEG")
        for ch in (1, 2, 3):
            self.set_current(ch, float(i_rms))
            self.set_current_phase(ch, angles[ch])



    def ramp_voltage(
        self,
        phase: Union[PhaseName, int],
        start_v: float,
        target_v: float,
        slew_v_per_s: float,
        step_time_s: float = 0.02,
        simulate_only: bool = True,
    ) -> None:
        p = _phase_index(phase)
        if slew_v_per_s <= 0:
            raise ValueError("slew_v_per_s must be > 0")
        dv = target_v - start_v
        if simulate_only or abs(dv) < 1e-12:
            self.set_voltage(p, target_v)
            return
        import time
        total_time = abs(dv) / slew_v_per_s
        steps = max(1, int(total_time / step_time_s)
                    ) if total_time > step_time_s else 1
        for k in range(1, steps+1):
            v = start_v + dv*(k/steps)
            self.set_voltage(p, v)
            time.sleep(step_time_s)

    def ramp_current(
        self,
        phase: Union[PhaseName, int],
        start_a: float,
        target_a: float,
        slew_a_per_s: float,
        step_time_s: float = 0.02,
        simulate_only: bool = True,
    ) -> None:
        p = _phase_index(phase)
        if slew_a_per_s <= 0:
            raise ValueError("slew_a_per_s must be > 0")
        di = target_a - start_a
        if simulate_only or abs(di) < 1e-12:
            self.set_current(p, target_a)
            return
        import time
        total_time = abs(di) / slew_a_per_s
        steps = max(1, int(total_time / step_time_s)
                    ) if total_time > step_time_s else 1
        for k in range(1, steps+1):
            i = start_a + di*(k/steps)
            self.set_current(p, i)
            time.sleep(step_time_s)

    def apply_voltage_dip(
        self,
        phase: Union[PhaseName, int],
        nominal_v: float,
        dip_percent: float,
        duration_s: float = 0.0,
        restore: bool = True,
        simulate_only: bool = True,
        slew_v_per_s: float | None = None,
    ) -> None:
        p = _phase_index(phase)
        start_v = nominal_v
        target = nominal_v * (1.0 - float(dip_percent)/100.0)
        if slew_v_per_s:
            self.ramp_voltage(p, start_v, target, float(
                slew_v_per_s), simulate_only=simulate_only)
        else:
            self.set_voltage(p, target)
        if duration_s and not simulate_only:
            import time
            time.sleep(float(duration_s))
        if restore:
            if slew_v_per_s:
                self.ramp_voltage(p, target, start_v, float(
                    slew_v_per_s), simulate_only=simulate_only)
            else:
                self.set_voltage(p, start_v)

    def apply_voltage_swell(
        self,
        phase: Union[PhaseName, int],
        nominal_v: float,
        swell_percent: float,
        duration_s: float = 0.0,
        restore: bool = True,
        simulate_only: bool = True,
        slew_v_per_s: float | None = None,
    ) -> None:
        p = _phase_index(phase)
        start_v = nominal_v
        target = nominal_v * (1.0 + float(swell_percent)/100.0)
        if slew_v_per_s:
            self.ramp_voltage(p, start_v, target, float(
                slew_v_per_s), simulate_only=simulate_only)
        else:
            self.set_voltage(p, target)
        if duration_s and not simulate_only:
            import time
            time.sleep(float(duration_s))
        if restore:
            if slew_v_per_s:
                self.ramp_voltage(p, target, start_v, float(
                    slew_v_per_s), simulate_only=simulate_only)
            else:
                self.set_voltage(p, start_v)

    def dip_set_env(self, phase: Union[PhaseName,int], change_to_percent: float, ramp_in: float,
                    duration: float, ramp_out: float, end_delay: float, kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        self.write(
    f"SOUR:PHAS{p}:{k}:DIP:ENV {
        change_to_percent:.9g},{
            ramp_in:.9g},{
                duration:.9g},{
                    ramp_out:.9g},{
                        end_delay:.9g}")
    def dip_get_env(
        self, phase: Union[PhaseName,int], field: str, kind: str="VOLT") -> float:
        p = _phase_index(phase)
        k = kind.upper()
        return float(self.query(f"SOUR:PHAS{p}:{k}:DIP:ENV? {field.upper()}"))

    def fhar_shape(self, phase: Union[PhaseName,int],
                   shape: str, kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        self.write(f"SOUR:PHAS{p}:{k}:FHAR:SHAP {shape.upper()}")
    def fhar_duty(self, phase: Union[PhaseName,int],
                  duty: float, kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        self.write(f"SOUR:PHAS{p}:{k}:FHAR:DUTY {duty:.9g}")
    def fhar_fluc(self, phase: Union[PhaseName,int], idx: int,
                  on: bool, duty: float | None = None, kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        if duty is None:
            self.write(
    f"SOUR:PHAS{p}:{k}:FHAR:FLUC{idx} {
        'ON' if on else 'OFF'}")
        else:
            self.write(
    f"SOUR:PHAS{p}:{k}:FHAR:FLUC{idx} {
        'ON' if on else 'OFF'},{
            duty:.9g}")
    def ihar_signal(self, phase: Union[PhaseName,int], slot: int, on: bool,
                    amplitude: float, freq_hz: float, kind: str="VOLT") -> None:
        p = _phase_index(phase)
        k = kind.upper()
        self.write(
    f"SOUR:PHAS{p}:{k}:IHAR:SIGN{slot} {
        'ON' if on else 'OFF'},{
            amplitude:.9g},{
                freq_hz:.9g}")
