"""Test suite package for pylab-sources."""
