# Namespace-migrated visa_shim implementation
# Copied from legacy src/visa_shim/visa_shim.py; adjusted for the
# pylab_sources namespace.
from __future__ import annotations

import json
import os
import re
import time

from colorama import Fore, Style
from colorama import init as colorama_init

colorama_init(strip=False, convert=False)

RESET = Style.RESET_ALL
NCYAN = getattr(Fore, "CYAN", "")
NGREY = getattr(Fore, "LIGHTBLACK_EX", "")


def _print_verbose(tag: str, msg: str) -> None:
    print(f"\t  {NCYAN}[{tag}]{RESET} {NGREY}{msg}{RESET}")

class VisaError(RuntimeError):
    pass

try:
    import pyvisa  # type: ignore
    _HAS_PYVISA = True
except Exception:
    pyvisa = None
    _HAS_PYVISA = False

def get_default_resource_manager():
    if _HAS_PYVISA:
        return pyvisa.ResourceManager()
    return FakeResourceManager()

def open_resource(resource_name: str,
                  *,
                  timeout_ms: int = 5000,
                  read_termination: str | None = "\n",
                  write_termination: str | None = "\n",
                  resource_manager=None,
                  strict: bool | None = None):
    """Drop-in helper mirroring pyvisa.ResourceManager.open_resource."""
    if resource_manager is None:
        upper = (resource_name or "").upper()
        if upper.startswith("FAKE") or "VIRTUAL" in upper:
            resource_manager = FakeResourceManager()
        else:
            resource_manager = get_default_resource_manager()

    try:
        res = resource_manager.open_resource(
    resource_name, strict=strict)  # type: ignore[call-arg]
    except TypeError:
        # pyvisa ResourceManager doesn't accept strict
        res = resource_manager.open_resource(
            resource_name)  # type: ignore[misc]

    try:
        res.timeout = timeout_ms  # type: ignore[attr-defined]
    except Exception:
        pass
    if read_termination is not None and hasattr(res, "read_termination"):
        try:
            # type: ignore[attr-defined]
            res.read_termination = read_termination
        except Exception:
            pass
    if write_termination is not None and hasattr(res, "write_termination"):
        try:
            # type: ignore[attr-defined]
            res.write_termination = write_termination
        except Exception:
            pass
    return res

def _load_limits():
    lim = {
        "voltage": {"min": 0.0, "max": 300.0},
        "current": {"min": 0.0, "max": 80.0},
        "harm_order_max": 50,
        "main_freq": 60.0,
    }
    env = os.environ.get("FLUKE_FAKE_LIMITS_JSON")
    if env:
        try:
            user = json.loads(env)
            for k, v in user.items():
                lim[k] = v
        except Exception:
            pass
    return lim

def _phase_state():
    def _chan():
        return {
            "stat": 0,
            "range": (0.0, 0.0),

            # Fundamental quantities
            "ampl": 0.0,                 # fundamental amplitude
            "phase_deg": 0.0,            # fundamental phase, stored in degrees

            # Multi-harmonic (MHAR) state
            "mhar_on": 0,
            # overall MHAR amplitude (ABS/PRMS depending on units)
            "mhar_ampl": 0.0,
            # order -> (amp_value_or_pct, phase_deg)
            "harm": {1: (0.0, 0.0), 0: (0.0, 0.0)},

            # Units and misc
            "units": "ABS",
            "equ": 0,
            "term": "UPPER",

            # Other features (compat)
            "fhar": {"shape": "SIN", "duty": 50.0, "fluc": {}},
            "ihar": {1: ("OFF", 0.0, 0.0), 2: ("OFF", 0.0, 0.0)},
        }
    return {"VOLT": _chan(), "CURR": _chan()}

class FakeFluke6105AResource:
    def __init__(self, resource_name: str, strict: bool |
                 None = None, *, verbose: bool = False):
        self.resource_name = resource_name
        self.timeout = 5000
        self.read_termination = "\n"
        self.write_termination = "\n"
        self._last_response = ""
        self._verbose = bool(verbose)
        self._strict = (
    os.environ.get(
        "FLUKE_FAKE_STRICT",
        "1").lower() not in (
            "0",
            "false",
             "no")) if strict is None else bool(strict)
        self._limits = _load_limits()
        self._state = {
            "freq": 50.0,
            "line_en": 0,
            "angle_units": "DEG",       # DEG | RAD
            "dip_time_units": "SEC",
            "phases": {i: _phase_state() for i in range(1, 4 + 1)},
            "dip": {"env": (100.0, 0.0, 0.0, 0.0, 0.0)},
            "errors": [],
            "outp": 0,
        }

        # Default usable ranges
        for p in self._state["phases"].values():
            p["VOLT"]["range"] = (
    self._limits["voltage"]["min"],
     self._limits["voltage"]["max"])
            p["CURR"]["range"] = (
    self._limits["current"]["min"],
     self._limits["current"]["max"])

    def set_verbose(self, verbose: bool) -> None:
        self._verbose = bool(verbose)

    def _log(self, msg: str) -> None:
        if self._verbose:
            _print_verbose("fluke_fake", msg)

    def clear(self): pass
    def close(self): pass

    def _delay(self):
        if os.environ.get("FAKE_ENABLE_DELAYS", "0") not in (
            "0", "False", "false", "NO", "no"):
            time.sleep(float(os.environ.get("FAKE_DELAY_S", "0.01")))

    def write(self, cmd: str):
        cmd = cmd.strip()
        if "?" in cmd:
            self._last_response = self._handle_query(cmd)  # may raise
        else:
            self._handle_cmd(cmd)
        self._delay()

    def read(self) -> str:
        resp = self._last_response
        self._last_response = ""
        term = self.read_termination or ""
        if resp.endswith(term) or term == "":
            return resp
        return resp + term

    def query(self, cmd: str) -> str:
        self.write(cmd.strip())
        return self.read()

    def _push_err(self, code: int, msg: str):
        self._state["errors"].append(f'{code},"{msg}"')

    # ---------------------------- COMMAND HANDLER ---------------------------- #
    def _handle_cmd(self, cmd: str):
        up = cmd.upper()

        if up == "*RST":
            self.__init__(
    self.resource_name,
    strict=self._strict,
     verbose=self._verbose)
            return
        if up == "*CLS":
            self._state["errors"].clear()
            return
        if up.startswith("OUTP:STAT"):
            self._state["outp"] = 1 if up.endswith("ON") else 0
            return

        # Frequency & line lock
        if up.startswith("SOUR:FREQ "):
            try:
                f = float(cmd.split(" ", 1)[1])
                self._state["freq"] = f
                self._log(f"Frequency command -> {f} Hz")
            except Exception:
                self._push_err(100, "Bad parameter")
            return
        if up.startswith("SOUR:FREQ:LINE"):
            try:
                self._state["line_en"] = 1 if int(cmd.split(" ", 1)[1]) else 0
                if self._state["line_en"]:
                    self._state["freq"] = float(
                        self._limits.get("main_freq", 60.0))
                self._log(
                    f"Line lock -> {'ENABLED' if self._state['line_en'] else 'DISABLED'}")
            except Exception:
                self._state["line_en"] = 0
            return

        # Units
        if up.startswith("UNIT:ANGLE"):
            self._state["angle_units"] = up.split()[-1]
            return
        if up.startswith("UNIT:MHAR:VOLT"):
            for p in self._state["phases"].values():
                p["VOLT"]["units"] = up.split()[-1]
                return
        if up.startswith("UNIT:MHAR:CURR"):
            for p in self._state["phases"].values():
                p["CURR"]["units"] = up.split()[-1]
                return
        if up.startswith("UNIT:DIP:TIME"):
            self._state["dip_time_units"] = up.split()[-1]
            return

        if up.startswith("SOUR:PHAS"):
            # Extract phase number
            try:
                ph_str = up[len("SOUR:PHAS"):].split(":", 1)[0]
                p = int(ph_str)
                if p not in self._state["phases"]:
                    raise ValueError()
            except Exception:
                self._push_err(101, "Bad phase")
                return

            def _chan(kind):
                return self._state["phases"][p][kind]

            # On/off
            if ":VOLT:STAT" in up:
                _chan("VOLT")["stat"] = 1 if up.endswith(
                    "1") or up.endswith("ON") else 0
                return
            if ":CURR:STAT" in up:
                _chan("CURR")["stat"] = 1 if up.endswith(
                    "1") or up.endswith("ON") else 0
                return

            # Ranges
            if ":VOLT:RANG " in up:
                lo, hi = [float(x) for x in cmd.split(" ", 1)[1].split(",")]
                min_v = self._limits["voltage"]["min"]
                max_v = self._limits["voltage"]["max"]
                if lo < min_v or hi > max_v or lo >= hi:
                    self._push_err(230, "Voltage range out of bounds")
                    return
                _chan("VOLT")["range"] = (lo, hi)
                self._log(f"P{p} voltage range -> ({lo}, {hi})")
                return
            if ":CURR:RANG " in up:
                lo, hi = [float(x) for x in cmd.split(" ", 1)[1].split(",")]
                min_i = self._limits["current"]["min"]
                max_i = self._limits["current"]["max"]
                if lo < min_i or hi > max_i or lo >= hi:
                    self._push_err(231, "Current range out of bounds")
                    return
                _chan("CURR")["range"] = (lo, hi)
                self._log(f"P{p} current range -> ({lo}, {hi})")
                return

            # Current routing / equalizer
            if ":CURR:TERM:ROUT " in up:
                term = cmd.split()[-1].upper()
                if term not in ("UPPER", "LOWER"):
                    self._push_err(232, "Bad terminal")
                    return
                _chan("CURR")["term"] = term
                return
            if ":CURR:EQU:STAT " in up:
                _chan("CURR")["equ"] = 1 if up.endswith(
                    "1") or up.endswith("ON") else 0
                return
            if ":VOLT:EQU:STAT " in up:
                _chan("VOLT")["equ"] = 1 if up.endswith(
                    "1") or up.endswith("ON") else 0
                return

            # Fundamental amplitude/phase writes
            if ":VOLT:AMPL " in up:
                val = float(cmd.split(" ", 1)[1])
                lo, hi = _chan("VOLT")["range"]
                if hi == 0.0:
                    _chan("VOLT")["range"] = (
    self._limits["voltage"]["min"],
     self._limits["voltage"]["max"])
                elif not (lo <= val <= hi):
                    self._push_err(321, "Voltage amplitude exceeds range")
                    return
                _chan("VOLT")["ampl"] = val
                _chan("VOLT")["mhar_ampl"] = val
                self._log(f"P{p} voltage amplitude -> {val}")
                return

            if ":CURR:AMPL " in up:
                val = float(cmd.split(" ", 1)[1])
                lo, hi = _chan("CURR")["range"]
                if hi == 0.0:
                    _chan("CURR")["range"] = (
    self._limits["current"]["min"],
     self._limits["current"]["max"])
                elif not (lo <= val <= hi):
                    self._push_err(323, "Current amplitude exceeds range")
                    return
                _chan("CURR")["ampl"] = val
                _chan("CURR")["mhar_ampl"] = val
                self._log(f"P{p} current amplitude -> {val}")
                return

            if ":VOLT:PHAS " in up:
                phv = float(cmd.split(" ", 1)[1])
                if self._state["angle_units"] == "RAD":
                    phv = phv * 180.0 / 3.141592653589793
                _chan("VOLT")["phase_deg"] = phv
                self._log(f"P{p} voltage phase -> {phv} deg")
                return

            if ":CURR:PHAS " in up:
                phv = float(cmd.split(" ", 1)[1])
                if self._state["angle_units"] == "RAD":
                    phv = phv * 180.0 / 3.141592653589793
                _chan("CURR")["phase_deg"] = phv
                self._log(f"P{p} current phase -> {phv} deg")
                return

            # MHAR enable + overall amplitude
            if ":VOLT:MHAR:STAT" in up:
                _chan("VOLT")["mhar_on"] = 1 if up.endswith(
                    "1") or up.endswith("ON") else 0
                return
            if ":CURR:MHAR:STAT" in up:
                _chan("CURR")["mhar_on"] = 1 if up.endswith(
                    "1") or up.endswith("ON") else 0
                return

            if ":VOLT:MHAR:AMPL " in up:
                val = float(cmd.split(" ", 1)[1])
                lo, hi = _chan("VOLT")["range"]
                if hi == 0.0:
                    _chan("VOLT")["range"] = (
    self._limits["voltage"]["min"],
     self._limits["voltage"]["max"])
                elif not (lo <= val <= hi):
                    self._push_err(325, "Voltage MHAR amplitude exceeds range")
                    return
                _chan("VOLT")["mhar_ampl"] = val
                _chan("VOLT")["ampl"] = val
                self._log(f"P{p} voltage MHAR amplitude -> {val}")
                return

            if ":CURR:MHAR:AMPL " in up:
                val = float(cmd.split(" ", 1)[1])
                lo, hi = _chan("CURR")["range"]
                if hi == 0.0:
                    _chan("CURR")["range"] = (
    self._limits["current"]["min"],
     self._limits["current"]["max"])
                elif not (lo <= val <= hi):
                    self._push_err(327, "Current MHAR amplitude exceeds range")
                    return
                _chan("CURR")["mhar_ampl"] = val
                _chan("CURR")["ampl"] = val
                self._log(f"P{p} current MHAR amplitude -> {val}")
                return

            if ":VOLT:MHAR:CLE" in up:
                ch = _chan("VOLT")
                ch["harm"] = {1: (0.0, 0.0), 0: (0.0, 0.0)}
                return
            if ":CURR:MHAR:CLE" in up:
                ch = _chan("CURR")
                ch["harm"] = {1: (0.0, 0.0), 0: (0.0, 0.0)}
                return

            # Harmonic writes — long form: ...:MHAR:HARMonic{n} {amp},{phase}
            m_long_v = re.search(r":VOLT:MHAR:HARMONIC(\d+)\s", up)
            m_long_i = re.search(r":CURR:MHAR:HARMONIC(\d+)\s", up)
            if m_long_v or m_long_i:
                kind = "VOLT" if m_long_v else "CURR"
                order = int((m_long_v or m_long_i).group(1))
                if not (0 <= order <= int(self._limits["harm_order_max"])):
                    self._push_err(
    340 if kind == "VOLT" else 342,
     "Harmonic order out of range")
                    return
                args = cmd.split(" ", 1)[1]
                a_s, ph_s = [x.strip() for x in args.split(",")]
                a, ph = float(a_s), float(ph_s)
                if self._state["angle_units"] == "RAD":
                    ph = ph * 180.0 / 3.141592653589793
                ch = _chan(kind)
                if ch["mhar_on"] == 0:
                    self._push_err(
    341 if kind == "VOLT" else 343,
     f"{kind} MHAR not enabled")
                    return
                ch["harm"][order] = (a, ph)
                if order == 1:
                    if ch["units"] == "ABS":
                        ch["ampl"] = a
                        if ch["mhar_ampl"] == 0.0:
                            ch["mhar_ampl"] = a
                    else:
                        ch["ampl"] = ch["mhar_ampl"] * (a / 100.0)
                self._log(
    f"P{p} {
        kind.lower()} harmonic {order} -> amp {a}, phase {ph} deg")
                return

            # Harmonic writes — short form (compat when not strict):
            # ...:MHAR:HARM {n} {amp},{phase}
            if ":VOLT:MHAR:HARM" in up or ":CURR:MHAR:HARM" in up:
                if self._strict:
                    self._push_err(-113, "Undefined header")
                    return
                right = cmd.split("MHAR:HARM", 1)[1].strip()
                parts = right.split(None, 1)
                order = int(parts[0])
                args = parts[1] if len(parts) > 1 else ""
                a_s, ph_s = [x.strip() for x in args.split(",")]
                a, ph = float(a_s), float(ph_s)
                if self._state["angle_units"] == "RAD":
                    ph = ph * 180.0 / 3.141592653589793
                kind = "VOLT" if ":VOLT:MHAR:HARM" in up else "CURR"
                ch = _chan(kind)
                if ch["mhar_on"] == 0:
                    self._push_err(
    341 if kind == "VOLT" else 343,
     f"{kind} MHAR not enabled")
                    return
                ch["harm"][order] = (a, ph)
                if order == 1:
                    if ch["units"] == "ABS":
                        ch["ampl"] = a
                        if ch["mhar_ampl"] == 0.0:
                            ch["mhar_ampl"] = a
                    else:
                        ch["ampl"] = ch["mhar_ampl"] * (a / 100.0)
                self._log(
    f"P{p} {
        kind.lower()} harmonic {order} -> amp {a}, phase {ph} deg")
                return

            # Fundamental amplitude via LEVEL path (some drivers use this)
            if ":VOLT:LEV:AMPL " in up:
                val = float(cmd.split(" ", 1)[1])
                lo, hi = _chan("VOLT")["range"]
                if hi == 0.0:
                    _chan("VOLT")["range"] = (
    self._limits["voltage"]["min"],
     self._limits["voltage"]["max"])
                elif not (lo <= val <= hi):
                    self._push_err(321, "Voltage amplitude exceeds range")
                    return
                _chan("VOLT")["ampl"] = val
                _chan("VOLT")["mhar_ampl"] = val
                self._log(f"P{p} voltage amplitude -> {val}")
                return

            if ":CURR:LEV:AMPL " in up:
                val = float(cmd.split(" ", 1)[1])
                lo, hi = _chan("CURR")["range"]
                if hi == 0.0:
                    _chan("CURR")["range"] = (
    self._limits["current"]["min"],
     self._limits["current"]["max"])
                elif not (lo <= val <= hi):
                    self._push_err(323, "Current amplitude exceeds range")
                    return
                _chan("CURR")["ampl"] = val
                _chan("CURR")["mhar_ampl"] = val
                self._log(f"P{p} current amplitude -> {val}")
                return

            # DIP ENV
            if ":DIP:ENV " in up:
                vals = [float(x) for x in cmd.split(" ", 1)[1].split(",")]
                if len(vals) == 5:
                    change_to = vals[0]
                    if not (0.0 <= change_to <= 200.0):
                        self._push_err(
    360, "DIP change-to percent out of bounds")
                        return
                    self._state["dip"]["env"] = tuple(vals)
                    return

        self._push_err(200, "Command not recognized")

    # ----------------------------- QUERY HANDLER ----------------------------- #
    def _handle_query(self, cmd: str) -> str:
        up = cmd.upper().strip()

        if up == "*IDN?":
            return "Fluke,6105A,FAKE,1.7"
        if up == "*OPC?":
            return "1"
        if up == "SYST:ERR?":
            if self._state["errors"]:
                return self._state["errors"].pop(0)
            return '0,"No error"'

        if up == "SOUR:FREQ?":
            return str(self._state["freq"])
        if up == "SOUR:FREQ:LOCK?":
            return "1" if self._state["line_en"] else "0"

        if up == "UNIT:ANGLE?":
            return self._state["angle_units"]
        if up == "UNIT:MHAR:VOLT?":
            return self._state["phases"][1]["VOLT"]["units"]
        if up == "UNIT:MHAR:CURR?":
            return self._state["phases"][1]["CURR"]["units"]
        if up == "UNIT:DIP:TIME?":
            return self._state["dip_time_units"]

        if up.startswith("SOUR:PHAS"):
            # Phase number
            try:
                ph_str = up[len("SOUR:PHAS"):].split(":", 1)[0]
                p = int(ph_str)
                if p not in self._state["phases"]:
                    raise ValueError()
            except Exception:
                return '101,"Bad phase"'

            rest_up = up.split(":", 2)[2]
            chv = self._state["phases"][p]["VOLT"]
            chi = self._state["phases"][p]["CURR"]

            # Status / ranges
            if rest_up == "VOLT:STAT?":
                return "1" if chv["stat"] else "0"
            if rest_up == "CURR:STAT?":
                return "1" if chi["stat"] else "0"
            if rest_up == "VOLT:RANG? LOW":
                return str(chv["range"][0])
            if rest_up == "VOLT:RANG? HIGH":
                return str(chv["range"][1])
            if rest_up == "CURR:RANG? LOW":
                return str(chi["range"][0])
            if rest_up == "CURR:RANG? HIGH":
                return str(chi["range"][1])

            # Fundamental amplitude / phase
            if rest_up == "VOLT:AMPL?":
                return str(chv["ampl"])
            if rest_up == "CURR:AMPL?":
                return str(chi["ampl"])
            if rest_up == "VOLT:PHAS?":
                return str(chv["phase_deg"])
            if rest_up == "CURR:PHAS?":
                return str(chi["phase_deg"])

            # MHAR amplitude (overall)
            if rest_up == "VOLT:MHAR:AMPL?":
                return str(chv["mhar_ampl"])
            if rest_up == "CURR:MHAR:AMPL?":
                return str(chi["mhar_ampl"])

            # Level amplitude (compat)
            if rest_up == "VOLT:LEV:AMPL?":
                return str(chv["ampl"])
            if rest_up == "CURR:LEV:AMPL?":
                return str(chi["ampl"])

            # Long-form harmonic queries:
            #   ...:MHAR:HARMonic<n>?            -> "amp,phase"
            #   ...:MHAR:HARMonic<n>:PANGle?     -> "phase"
            #   ...:MHAR:HARMonic<n>:AMPLitude?  -> "amp" (push -113 if strict)
            m_v = re.search(
    r"^VOLT:MHAR:HARMONIC(\d+)(?::(AMPLITUDE|PANGLE))?\?$",
     rest_up)
            m_i = re.search(
    r"^CURR:MHAR:HARMONIC(\d+)(?::(AMPLITUDE|PANGLE))?\?$",
     rest_up)
            if m_v or m_i:
                kind = "VOLT" if m_v else "CURR"
                order = int((m_v or m_i).group(1))
                sub = (m_v or m_i).group(2)  # None | AMPLITUDE | PANGLE
                ch = chv if kind == "VOLT" else chi
                a, ph = ch["harm"].get(order, (0.0, 0.0))
                if sub is None:
                    return f"{a},{ph}"
                if sub == "PANGLE":
                    return f"{ph}"
                if sub == "AMPLITUDE":
                    if self._strict:
                        self._push_err(-113, "Undefined header")
                    return f"{a}"

            # Short-form harmonic queries (compat only if not strict)
            if rest_up.startswith("VOLT:MHAR:HARM? "):
                if self._strict:
                    raise RuntimeError(
                        "Query not supported on 6105A: VOLT:MHAR:HARM? n")
                order = int(cmd.split(" ", 1)[1])
                a, ph = chv["harm"].get(order, (0.0, 0.0))
                return f"{a},{ph}"
            if rest_up.startswith("CURR:MHAR:HARM? "):
                if self._strict:
                    raise RuntimeError(
                        "Query not supported on 6105A: CURR:MHAR:HARM? n")
                order = int(cmd.split(" ", 1)[1])
                a, ph = chi["harm"].get(order, (0.0, 0.0))
                return f"{a},{ph}"

            # DIP env
            if rest_up.startswith(
                "VOLT:DIP:ENV?") or rest_up.startswith("CURR:DIP:ENV?"):
                fld = rest_up.split()[-1]
                env = self._state["dip"]["env"]
                idx_map = {
    "CHANGETO": 0,
    "RIN": 1,
    "DUR": 2,
    "ROUT": 3,
     "EDEL": 4}
                return str(env[idx_map.get(fld, 0)])

        return '200,"Query not recognized"'


class FakeYokoLs3300Resource:
    """Lightweight simulator for the Yokogawa LS3300 single-phase source."""

    def __init__(self, resource_name: str, *, verbose: bool = False):
        self.resource_name = resource_name
        self.timeout = 2000
        self.read_termination = "\n"
        self.write_termination = "\n"
        self._last_response = ""
        self._verbose = bool(verbose)
        self._state = {
            "frequency_hz": 50.0,
            "voltage_range": 100.0,
            "voltage_level": 0.0,
            "voltage_phase_deg": 0.0,
            "voltage_ratio": 100.0,
            "current_range": 0.1,
            "current_level": 0.0,
            "current_phase_deg": 0.0,
            "current_ratio": 100.0,
            "output_on": False,
            "voltage_output": False,
            "current_output": False,
            "osc_source": "INT",
        }

    def set_verbose(self, verbose: bool) -> None:
        self._verbose = bool(verbose)

    def _log(self, msg: str) -> None:
        if self._verbose:
            _print_verbose("yoko_fake", msg)

    def clear(self):  # pragma: no cover - no error queue maintained yet
        self._last_response = ""

    def close(self):  # pragma: no cover - nothing to release
        pass

    def _write_value(self, cmd: str, setter):
        try:
            _, raw = cmd.split(None, 1)
            setter(float(raw))
        except Exception as exc:  # pragma: no cover - defensive
            raise RuntimeError(f"Bad parameter for {cmd!r}: {exc}") from exc

    def write(self, cmd: str):
        cmd = cmd.strip()
        if not cmd:
            return
        if "?" in cmd:
            self._last_response = self._handle_query(cmd)
            return
        self._handle_cmd(cmd)

    def read(self) -> str:
        resp = self._last_response
        self._last_response = ""
        term = self.read_termination or ""
        if resp.endswith(term) or term == "":
            return resp
        return resp + term

    def query(self, cmd: str) -> str:
        self.write(cmd)
        return self.read()

    # ---------------------------- COMMAND HANDLER ---------------------------- #
    def _handle_cmd(self, cmd: str) -> None:
        up = cmd.upper()
        norm = up if up.startswith(":") else f":{up}"
        if up == "*RST":
            self.__init__(self.resource_name, verbose=self._verbose)
            return
        if up == "*CLS":
            return

        if norm.startswith(":SOURCE:VOLTAGE:RANGE "):
            def _set_range(v: float) -> None:
                self._state["voltage_range"] = v
                self._log(f"Voltage range -> {v}")
            self._write_value(cmd, _set_range)
            return
        if norm.startswith(":SOURCE:VOLTAGE:LEVEL:VALUE "):
            def _set_level(v: float) -> None:
                self._state["voltage_level"] = v
                self._log(f"Voltage level -> {v} V")
            self._write_value(cmd, _set_level)
            return
        if norm.startswith(":SOURCE:VOLTAGE:LEVEL:RATIO "):
            def _set_ratio(v: float) -> None:
                self._state["voltage_ratio"] = v
                self._log(f"Voltage ratio -> {v}%")
            self._write_value(cmd, _set_ratio)
            return
        if norm.startswith(":SOURCE:VOLTAGE:PHASE:VALUE "):
            def _set_phase(v: float) -> None:
                self._state["voltage_phase_deg"] = v
                self._log(f"Voltage phase -> {v} deg")
            self._write_value(cmd, _set_phase)
            return

        if norm.startswith(":SOURCE:CURRENT:RANGE "):
            def _set_cur_range(v: float) -> None:
                self._state["current_range"] = v
                self._log(f"Current range -> {v}")
            self._write_value(cmd, _set_cur_range)
            return
        if norm.startswith(":SOURCE:CURRENT:LEVEL:VALUE "):
            def _set_cur_level(v: float) -> None:
                self._state["current_level"] = v
                self._log(f"Current level -> {v} A")
            self._write_value(cmd, _set_cur_level)
            return
        if norm.startswith(":SOURCE:CURRENT:LEVEL:RATIO "):
            def _set_cur_ratio(v: float) -> None:
                self._state["current_ratio"] = v
                self._log(f"Current ratio -> {v}%")
            self._write_value(cmd, _set_cur_ratio)
            return
        if norm.startswith(":SOURCE:CURRENT:PHASE:VALUE "):
            self._write_value(cmd, self._set_current_phase)
            return

        if norm.startswith(":OSCILLATOR:FREQUENCY "):
            def _set_freq(v: float) -> None:
                self._state["frequency_hz"] = v
                self._log(f"Frequency -> {v} Hz")
            self._write_value(cmd, _set_freq)
            return
        if norm.startswith(":OSCILLATOR:SOURCE "):
            src = cmd.rsplit(" ", 1)[-1].strip().upper()
            if src not in ("INTERNAL", "EXTERNAL"):
                raise RuntimeError(f"Bad oscillator source: {src}")
            self._state["osc_source"] = "INT" if src.startswith(
                "INT") else "EXT"
            return

        if norm.startswith(":OUTPUT:STATE "):
            self._state["output_on"] = up.endswith("ON")
            return
        if norm.startswith(":OUTPUT:SELECT:VOLTAGE1 "):
            self._state["voltage_output"] = up.endswith("ON")
            return
        if norm.startswith(":OUTPUT:SELECT:CURRENT1 "):
            self._state["current_output"] = up.endswith("ON")
            return

        raise RuntimeError(f"Command not recognized: {cmd}")

    def _set_current_phase(self, value: float):
        if not (-181.0 <= value <= 360.0):
            raise RuntimeError(
                "Current phase out of allowable input range (-181..360)")
        self._state["current_phase_deg"] = value
        self._log(f"Current phase -> {value} deg")

    # ----------------------------- QUERY HANDLER ----------------------------- #
    def _handle_query(self, cmd: str) -> str:
        up = cmd.upper().strip()
        norm = up if up.startswith(":") else f":{up}"
        if up == "*IDN?":
            return "Yokogawa,LS3300,FAKE,1.0"
        if up == "SYST:ERR?":
            return '0,"No error"'

        if norm == ":SOURCE:VOLTAGE:RANGE?":
            return f"{self._state['voltage_range']}"
        if norm == ":SOURCE:VOLTAGE:LEVEL:VALUE?":
            return f"{self._state['voltage_level']}"
        if norm == ":SOURCE:VOLTAGE:LEVEL:RATIO?":
            return f"{self._state['voltage_ratio']}"
        if norm == ":SOURCE:VOLTAGE:PHASE:VALUE?":
            return f"{self._state['voltage_phase_deg']}"

        if norm == ":SOURCE:CURRENT:RANGE?":
            return f"{self._state['current_range']}"
        if norm == ":SOURCE:CURRENT:LEVEL:VALUE?":
            return f"{self._state['current_level']}"
        if norm == ":SOURCE:CURRENT:LEVEL:RATIO?":
            return f"{self._state['current_ratio']}"
        if norm == ":SOURCE:CURRENT:PHASE:VALUE?":
            return f"{self._state['current_phase_deg']}"

        if norm == ":OSCILLATOR:FREQUENCY?":
            return f"{self._state['frequency_hz']}"
        if norm == ":OSCILLATOR:SOURCE?":
            return "INTERNAL" if self._state["osc_source"] == "INT" else "EXTERNAL"

        if norm == ":OUTPUT:STATE?":
            return "ON" if self._state["output_on"] else "OFF"
        if norm == ":OUTPUT:SELECT:VOLTAGE1?":
            return "ON" if self._state["voltage_output"] else "OFF"
        if norm == ":OUTPUT:SELECT:CURRENT1?":
            return "ON" if self._state["current_output"] else "OFF"

        raise RuntimeError(f"Query not recognized: {cmd}")


class FakeMessageBasedResource(FakeFluke6105AResource):
    """Backward-compatible entry point that currently returns the Fluke fake."""
    pass


def _default_fake_factory(resource_name: str, *,
                          strict: bool | None = None, verbose: bool = False):
    upper = (resource_name or "").upper()
    if "YOKO" in upper:
        return FakeYokoLs3300Resource(resource_name, verbose=verbose)
    return FakeFluke6105AResource(
        resource_name, strict=strict, verbose=verbose)

class FakeResourceManager:
    def __init__(self, *, resource_factory=None, verbose: bool = False):
        self._resources = {}
        self._factory = resource_factory or _default_fake_factory
        self._verbose = bool(verbose)

    def set_verbose(self, verbose: bool) -> None:
        self._verbose = bool(verbose)

    def open_resource(self, resource_name: str, *, strict: bool | None = None):
        res = self._factory(
    resource_name,
    strict=strict,
     verbose=self._verbose)
        if hasattr(res, "set_verbose"):
            res.set_verbose(self._verbose)
        elif hasattr(res, "verbose"):
            try:
                res.verbose = bool(self._verbose)
            except Exception:
                pass
        self._resources[resource_name] = res
        return res

    def close(self):
        self._resources.clear()

__all__ = [
    'VisaError', 'open_resource', 'get_default_resource_manager',
    'FakeFluke6105AResource', 'FakeYokoLs3300Resource', 'FakeMessageBasedResource',
    'FakeResourceManager'
]
