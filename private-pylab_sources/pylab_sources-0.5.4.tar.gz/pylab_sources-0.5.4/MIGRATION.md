# pylab-sources Migration Notes

## Target Layout
- `pylab_sources/` will expose a unified API for the existing signal source drivers (`fluke_6105a`, `source_3phase`, `nidaq`, `visa_shim`, `yoko_ls3300_single`, `yoko_ls3300_3phase_virtual`).
- Subpackages under `pylab_sources` map to instrument families while sharing common abstractions (e.g. communication helpers) that will ultimately live in `pylab-meter-comm`.

## Driver Inventory

| Driver | Current Path | Runtime Dependencies | Notable Assets | Notes |
| --- | --- | --- | --- | --- |
| Fluke 6105A | `drivers/fluke_6105a` | `pyvisa` | `docs/`, `examples/`, CLI entry point (`fluke-scpi`) | Initial driver copied into `pylab_sources.fluke`; review docs/CLI parity before publishing. |
| 3-Phase Source | `drivers/source_3phase` | `labautomation-visa-shim`, `labautomation-fluke-scpi`, `yoko_ls3300_*` | `README.md` | Aggregator that already composes Fluke and Yokogawa drivers. |
| NI-DAQ | `drivers/nidaq` | `nidaqmx` | `README.md`, `README_NI9262.md` | Ported to `pylab_sources.nidaq` with optional extras; update docs/tests accordingly. |
| VISA Shim | `drivers/visa_shim` | none today | `README.md` | Copied into `pylab_sources.visa_shim`; confirm env fallbacks and remove legacy references. |
| Yokogawa LS3300 (single) | `drivers/yoko_ls3300_single` | none | `README` references placeholder URLs | Copied into `pylab_sources.yokogawa`; verify doc updates and deprecate legacy name. |
| Yokogawa LS3300 Virtual 3-Phase | `drivers/yoko_ls3300_3phase_virtual` | `yoko_ls3300_single>=0.1.0` | none | Wrapped in `pylab_sources.yokogawa.ThreePhaseLS3300Virtual`. |
| Source 3-phase orchestration | `drivers/source_3phase` | N/A | tests (`test_ops_angles.py`) | Ported to `pylab_sources.source3p` with updated factory + operations. |

## Migration Steps
1. **Define Public API** – decide on `pylab_sources` package structure (e.g. `pylab_sources.fluke`, `pylab_sources.yokogawa`, `pylab_sources.aggregates`) and document import targets in `README.md`.
2. **Port Code Incrementally** – move one driver at a time into the new package, preserving tests and docs. Update imports to the unified namespace while keeping original modules available inside the monorepo until consumers switch.
3. **Normalize Dependencies** – translate existing `setuptools` metadata into Hatch’s `dependencies` section; remove old tag-based versioning and ensure extras (CLI entry points) are captured via `project.scripts`.
4. **Handle Legacy Assets** – copy docs/examples that remain relevant; otherwise archive them with release notes. Note any binary blobs or config files that need a new home.
5. **Adapt Environment Hooks** – wrap VISA or NI-DAQ environment checks so the package gracefully bypasses corporate-only services when env vars are absent (to support off-network development).
6. **Provide Editable Install Guidance** – document `pip install -e ../pyLabSources` and Hatch commands in the root README or `agents.md`.
7. **Deprecate Old Packages** – once apps consume `pylab-sources`, add deprecation notices to legacy packages and prepare to archive/remove them from this repo.

## Outstanding Questions
- Determine whether the Fluke CLI should remain bundled or move to a separate app-specific package.
- Confirm if any datastore/Zscaler configuration is required for VISA shim fallbacks; capture mitigation in tests.
