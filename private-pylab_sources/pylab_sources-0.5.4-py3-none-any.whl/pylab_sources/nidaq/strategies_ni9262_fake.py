# pylab_sources/nidaq/strategies_ni9262_fake.py
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

from ..source3p.errors import UnsupportedFeatureError
from ..source3p.strategy import Capability, SourceStrategy

V_PK_TO_DAQ = 10.0 / 450.0
I_PK_TO_DAQ = 10.0 / 30.0
_DAQ_LIMIT  = 10.0
_MIN_F_HZ   = 42.0
_MAX_F_HZ   = 69.0

PhaseName = str

@dataclass
class _PhaseState:
    v_pk: float = 0.0
    i_pk: float = 0.0
    ang_deg_v: float = 0.0
    ang_deg_i: float = 0.0

class Ni9262FakeStrategy(SourceStrategy):
    """Fake/simulated NI-9262 3-phase source (no hardware)."""
    def __init__(
        self,
        master_mod: str = "cDAQ1Mod1",
        slave_mod: str  = "cDAQ1Mod2",
        chan_map: Optional[Dict[str, str]] = None,
        samples_per_cycle: int = 4096,
        amplitudes_are_rms: bool = True,
        *,
        verbose: bool = False,
    ) -> None:
        self._master_mod = str(master_mod)
        self._slave_mod  = str(slave_mod)
        self._chan_map   = dict(chan_map or {
            "V:P1": "cDAQ1Mod1/ao0", "V:P2": "cDAQ1Mod1/ao1", "V:P3": "cDAQ1Mod1/ao2",
            "I:P1": "cDAQ1Mod2/ao0", "I:P2": "cDAQ1Mod2/ao1", "I:P3": "cDAQ1Mod2/ao2",
        })
        if samples_per_cycle <= 0:
            raise ValueError("samples_per_cycle must be > 0")
        self._N = int(samples_per_cycle)
        self._amps_are_rms = bool(amplitudes_are_rms)
        self._verbose = bool(verbose)

        self._freq_hz: float = 50.0
        self._ph: Dict[PhaseName, _PhaseState] = {
            "P1": _PhaseState(0.0, 0.0,   0.0,   0.0),
            "P2": _PhaseState(0.0, 0.0, -120.0, -120.0),
            "P3": _PhaseState(0.0, 0.0, +120.0, +120.0),
        }
        self._running = False
        self._last_buffers: Optional[Tuple[Dict[str, List[str]],
            Dict[str, List[List[float]]], float]] = None

    def identify(self) -> str:
        return (
            "NI-9262 FAKE 3-phase "
            f"(master={self._master_mod}, slave={self._slave_mod}, N={self._N})"
        )

    def capabilities(self) -> Iterable[Capability]:
        return {
            Capability.ThreePhase,
            Capability.VoltageAmplitude,
            Capability.CurrentAmplitude,
            Capability.VoltagePhaseAngle,
            Capability.CurrentPhaseAngle,
            Capability.Frequency,
        }

    def set_samples_per_cycle(self, N: int) -> None:
        if N <= 0:
            raise ValueError("samples_per_cycle must be > 0")
        self._N = int(N)

    def set_frequency(self, f_hz: float) -> None:
        f = float(f_hz)
        if not (_MIN_F_HZ <= f <= _MAX_F_HZ):
            raise ValueError(
    f"frequency {f} Hz out of allowed range [{_MIN_F_HZ}, {_MAX_F_HZ}]")
        self._freq_hz = f

    def _to_pk(self, amp_in: float) -> float:
        return float(amp_in) * (math.sqrt(2.0) if self._amps_are_rms else 1.0)

    def set_voltages(self, volts: Dict[str, float]) -> None:
        for p, v in volts.items():
            self._ph[p].v_pk = self._to_pk(v)

    def set_currents(self, amps: Dict[str, float]) -> None:
        for p, a in amps.items():
            self._ph[p].i_pk = self._to_pk(a)

    def set_phases(self, degrees: Dict[str, float]) -> None:
        for p, deg in degrees.items():
            d = float(deg)
            self._ph[p].ang_deg_v = d
            self._ph[p].ang_deg_i = d

    def set_phase_vfa(self, phase: str, voltage_v: float,
                      freq_hz: float, angle_deg: float) -> None:
        self.set_frequency(freq_hz)
        self._ph[phase].v_pk = self._to_pk(voltage_v)
        self._ph[phase].ang_deg_v = float(angle_deg)

    def set_pf(self, pf: float, convention: str = "IEEE") -> None:
        raise UnsupportedFeatureError(
            "PF shaping not implemented for Ni9262FakeStrategy")

    def on(self) -> None:
        self._apply_internal(start=True)

    def off(self) -> None:
        self.all_off()

    def all_off(self) -> None:
        self._running = False
        self._last_buffers = None

    def apply(self) -> None:
        self._apply_internal(start=True)

    def _build_buffers(
        self) -> Tuple[Dict[str, List[str]], Dict[str, List[List[float]]], float]:
        N  = self._N
        fs = self._freq_hz * N
        k = list(range(N))
        w = 2.0 * math.pi / N

        def build(kind: str, phase: str) -> List[float]:
            st = self._ph[phase]
            if kind == "V":
                amp_pk = st.v_pk
                ang = st.ang_deg_v
                scale = V_PK_TO_DAQ
            else:
                amp_pk = st.i_pk
                ang = st.ang_deg_i
                scale = I_PK_TO_DAQ
            phi = math.radians(ang)
            vals = [amp_pk * math.sin(w*i + phi) * scale for i in k]
            return [max(-_DAQ_LIMIT, min(_DAQ_LIMIT, v)) for v in vals]

        logicals = [("V","P1"), ("V","P2"), ("V","P3"),
                     ("I","P1"), ("I","P2"), ("I","P3")]
        master_phys: List[str] = []
        slave_phys: List[str]  = []
        master_data: List[List[float]] = []
        slave_data: List[List[float]] = []

        for kind, phase in logicals:
            key = f"{kind}:{phase}"
            phys = self._chan_map.get(key)
            if not phys:
                continue
            data = build(kind, phase)
            if phys.startswith(self._master_mod + "/"):
                master_phys.append(phys)
                master_data.append(data)
            elif phys.startswith(self._slave_mod + "/"):
                slave_phys.append(phys)
                slave_data.append(data)
            else:
                raise ValueError(
    f"Channel '{phys}' not on master '{
        self._master_mod}' or slave '{
            self._slave_mod}'")

        return {"master": master_phys, "slave": slave_phys}, {
            "master": master_data, "slave": slave_data}, fs

    def _apply_internal(self, start: bool) -> None:
        phys, data, fs = self._build_buffers()
        self._last_buffers = (phys, data, fs)
        self._running = bool(start)

    def last_buffers(
        self) -> Optional[Tuple[Dict[str, List[str]], Dict[str, List[List[float]]], float]]:
        return self._last_buffers

    # ---- Implement abstract interface (no hardware side-effects) ----
    def open(self) -> None:
        # Nothing to do for fake
        pass

    def close(self) -> None:
        self.all_off()

    def set_phase_current(self, phase: str, current_a: float) -> None:
        self._ph[phase].i_pk = self._to_pk(current_a)

    def set_phase_voltage(self, phase: str, voltage_v: float) -> None:
        self._ph[phase].v_pk = self._to_pk(voltage_v)

    def set_phase_voltage_angle(self, phase: str, angle_deg: float) -> None:
        self._ph[phase].ang_deg_v = float(angle_deg)

    def set_phase_current_angle(self, phase: str, angle_deg: float) -> None:
        self._ph[phase].ang_deg_i = float(angle_deg)
