# pylab_sources/source3p/factory.py
from __future__ import annotations

import logging
from typing import Optional

from ..nidaq.strategies_ni9262_fake import Ni9262FakeStrategy
from .context import SourceContext
from .strategies_fake import FakeStrategy
from .strategies_fluke import FlukeStrategy
from .strategies_nidaq import NiDAQStrategy
from .strategies_yoko import Yokogawa3PhaseStrategy

LOGGER = logging.getLogger(__name__)


class SourceFactory:
    """
    Central place to construct a 3-phase SourceContext based on CLI inputs.

    source_kind:
      - 'auto'  : prefer Yoko if all three yoko visas are provided; else Fluke if VISA
                  is provided and not a virtual sentinel; else Fake.
      - 'yoko'  : requires yoko_p1, yoko_p2, yoko_p3
      - 'fluke' : requires source_address
      - 'fake' / 'fake_*' : no extra params

    source_address:
      - VISA resource string for Fluke (e.g., "GPIB0::18::INSTR")
      - If set to "FLUKE::VIRTUAL" we treat as Fake unless source_kind='fluke' forces it.

    yoko_p1/2/3:
      - VISA resource strings for three LS3300s (phase 1/2/3)
    """

    @staticmethod
    def build_from_resource(source_resource, *, src_verbose: bool = False):
        """
        A source resource is a dict containing at a minimum a key named 'sourcetype'.
        This value is then used to determine which strategy to use. Other keys
        from the dict are needed based on the given type:
        - fluke6105a: requires 'addr' key with VISA resource string
        - yoko: requires 'yoko_p1_addr', 'yoko_p2_addr', 'yoko_p3_addr'
          keys with VISA resource strings
        Any other value will result in the Fake strategy being used.
        """
        if source_resource['sourcetype'] == 'fluke6105a':
            addr = source_resource['addr']
            strat = FlukeStrategy(addr, verbose=src_verbose)
        elif source_resource['sourcetype'] == 'yoko':
            strat = Yokogawa3PhaseStrategy(
                source_resource['yoko_p1_addr'],
                source_resource['yoko_p2_addr'],
                source_resource['yoko_p3_addr'],
                verbose=src_verbose,
            )
        else:
            LOGGER.warning(
    "Unknown source type '%s', using FakeStrategy.",
     source_resource['sourcetype'])
            strat = FakeStrategy(verbose=src_verbose)
        return SourceContext(strategy=strat, verbose=src_verbose)


    @staticmethod
    def build(
        *,
        source_kind: str = "auto",
        source_address: Optional[str] = None,
        src_verbose: bool = False,
        nidaq_voltage_mod: Optional[str] = None,
        nidaq_current_mod: Optional[str] = None,
        nidaq_map: Optional[dict] = None,
        nidaq_resource: Optional[str] = None,
        master_mod: Optional[str] = None,
        slave_mod: Optional[str] = None,
        samples_per_cycle: int = 4096,
        yoko_p1: Optional[str] = None,
        yoko_p2: Optional[str] = None,
        yoko_p3: Optional[str] = None,
    ) -> SourceContext:
        kind = (source_kind or "auto").strip().lower()

        # Convenience flags
        has_yoko = bool(yoko_p1 and yoko_p2 and yoko_p3)

        addr_norm = (source_address or "").strip()
        addr_upper = addr_norm.upper()

        if kind == "auto":
            print("ERROR: auto isn't supported, it's going to be deleted")

        # ========= Yokogawa ============
        elif kind == "yoko":
            if has_yoko:
                strat = Yokogawa3PhaseStrategy(
    yoko_p1, yoko_p2, yoko_p3, verbose=src_verbose)  # type: ignore[arg-type]
            elif addr_upper.startswith("YOKO::VIRTUAL"):
                base = addr_norm or "YOKO::VIRTUAL"
                strat = Yokogawa3PhaseStrategy(
                    f"{base}:P1",
                    f"{base}:P2",
                    f"{base}:P3",
                    verbose=src_verbose,
                )
            else:
                raise ValueError(
                    "source_kind=yoko requires --yoko_p1/2/3 or --source_address YOKO::VIRTUAL.")

        # ========= Fluke ============
        elif kind == "fluke":
            use_address = addr_norm or "FLUKE::VIRTUAL"
            strat = FlukeStrategy(use_address, verbose=src_verbose)

        elif kind in ("fake", "fake_generic"):
            strat = FakeStrategy(verbose=src_verbose)

        # ========= NIDAQ ============
        elif kind == "nidaq":
            # Prefer explicit mapping when possible
            if nidaq_map is not None:
                use_map = dict(nidaq_map)
            # support remapping from gui
            elif nidaq_voltage_mod and nidaq_current_mod:
                use_map = {
                    "V:P1": f"{nidaq_voltage_mod}/ao0",
                    "V:P2": f"{nidaq_voltage_mod}/ao1",
                    "V:P3": f"{nidaq_voltage_mod}/ao2",
                    "I:P1": f"{nidaq_current_mod}/ao0",
                    "I:P2": f"{nidaq_current_mod}/ao1",
                    "I:P3": f"{nidaq_current_mod}/ao2"
                }
            # If no mapping supplied, try a sensible default
            elif not nidaq_voltage_mod and not nidaq_current_mod:
                try:
                    from ..nidaq.ni_mappings import NI9262_DEFAULT_MAP
                    use_map = dict(NI9262_DEFAULT_MAP)
                except Exception:
                    use_map = {}
            else:
                use_map = dict(nidaq_map)
            # Convert to channels for driver-addressing
            channels = [
                use_map["V:P1"],
                use_map["V:P2"],
                use_map["V:P3"],
                use_map["I:P1"],
                use_map["I:P2"],
                use_map["I:P3"],
            ]
            strat = NiDAQStrategy(
    channels,
    samples_per_cycle=samples_per_cycle,
     verbose=src_verbose)
        
        elif kind == "nidaq_fake":
            # Parse addresses like 'cDAQ1Mod1,cDAQ1Mod2' or
            # 'master=...,slave=...'
            if not (master_mod and slave_mod):
                if nidaq_resource:
                    parts = [p.strip() for p in str(
                        nidaq_resource).split(",") if p.strip()]
                    if len(parts) == 2:
                        master_mod, slave_mod = parts[0], parts[1]
                    else:
                        try:
                            kv = dict(item.split("=", 1)
                                      for item in str(nidaq_resource).split(","))
                            master_mod = master_mod or kv.get("master")
                            slave_mod  = slave_mod  or kv.get("slave")
                        except Exception:
                            pass
            if not (master_mod and slave_mod):
                master_mod = master_mod or "cDAQ1Mod1"
                slave_mod  = slave_mod  or "cDAQ1Mod2"

            if nidaq_map is None:
                try:
                    from ..nidaq.ni_mappings import NI9262_DEFAULT_MAP
                    use_map = dict(NI9262_DEFAULT_MAP)
                except Exception:
                    use_map = {
                        "V:P1": "cDAQ1Mod1/ao0",
                        "V:P2": "cDAQ1Mod1/ao1",
                        "V:P3": "cDAQ1Mod1/ao2",
                        "I:P1": "cDAQ1Mod2/ao0",
                        "I:P2": "cDAQ1Mod2/ao1",
                        "I:P3": "cDAQ1Mod2/ao2",
                    }
            else:
                use_map = dict(nidaq_map)

            strat = Ni9262FakeStrategy(
    master_mod,
    slave_mod,
    use_map,
    samples_per_cycle=samples_per_cycle,
     verbose=src_verbose)
    
        elif "fake_generic" in kind:
            strat = FakeStrategy(verbose=src_verbose)
            
        elif kind in ("fake_yoko", "fake_fluke", "fake_nidaq9262"):
            raise ValueError(
    f"\n\nERROR: {source_kind} fake isn't currently implemented. Use fake_generic!")
            
        else:
            raise ValueError(f"Unknown source_kind '{source_kind}'")

        return SourceContext(strategy=strat, verbose=src_verbose)
