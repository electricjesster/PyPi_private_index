"""VISA transport abstraction under the unified pylab_sources namespace.

Provides `VisaTransport` with the same surface as the legacy
`visa_shim.transport.VisaTransport` so existing drivers can continue
unchanged after namespace migration.
"""
from __future__ import annotations

import time
from typing import Optional, Protocol

from .visa_shim import (
    FakeResourceManager,
    VisaError,
    get_default_resource_manager,
)


class _ResourceProto(Protocol):  # minimal structural typing for editor help
    timeout: int
    read_termination: str
    write_termination: str
    def write(self, cmd: str) -> None: ...
    def read(self) -> str: ...
    def query(self, cmd: str) -> str: ...
    def close(self) -> None: ...
    def clear(self) -> None: ...

class VisaTransport:
    def __init__(
        self,
        resource: _ResourceProto,
        *,
        read_termination: Optional[str] = '\n',
        write_termination: Optional[str] = '\n',
    ):
        self._res = resource
        if read_termination is not None and hasattr(
            self._res, 'read_termination'):
            try:
                # type: ignore[attr-defined]
                self._res.read_termination = read_termination
            except Exception:
                pass
        if write_termination is not None and hasattr(
            self._res, 'write_termination'):
            try:
                # type: ignore[attr-defined]
                self._res.write_termination = write_termination
            except Exception:
                pass

    @classmethod
    def open(
        cls,
        resource_name: str,
        *,
        timeout_ms: int = 5000,
        read_termination: Optional[str] = '\n',
        write_termination: Optional[str] = '\n',
        resource_manager=None,
        verbose: bool = False,
    ):
        try:
            # Choose resource manager: explicit -> fake (FAKE/VIRTUAL) ->
            # default
            if resource_manager is not None:
                rm = resource_manager
                if hasattr(rm, 'set_verbose'):
                    rm.set_verbose(verbose)
                elif hasattr(rm, 'verbose'):
                    try:
                        rm.verbose = bool(verbose)
                    except Exception:
                        pass
            else:
                upper = (resource_name or '').upper()
                if upper.startswith('FAKE') or 'VIRTUAL' in upper:
                    rm = FakeResourceManager(verbose=verbose)
                else:
                    rm = get_default_resource_manager()
            res = rm.open_resource(resource_name)  # type: ignore[attr-defined]
            if hasattr(res, 'set_verbose'):
                res.set_verbose(verbose)
            elif hasattr(res, 'verbose'):
                try:
                    res.verbose = bool(verbose)
                except Exception:
                    pass
            if hasattr(res, 'timeout'):
                try:
                    res.timeout = timeout_ms
                except Exception:
                    pass
            return cls(res, read_termination=read_termination,
                       write_termination=write_termination)
        except Exception as e:  # pragma: no cover - defensive path
            raise VisaError(f'Open failed for {resource_name!r}: {e}') from e

    def close(self):
        try:
            self._res.close()
        except Exception as e:
            raise VisaError(f'Close failed: {e}') from e

    def write(self, cmd: str):
        try:
            self._res.write(cmd)
        except Exception as e:
            raise VisaError(f'Write failed for {cmd!r}: {e}') from e

    def read(self) -> str:
        try:
            return self._res.read()
        except Exception as e:
            raise VisaError(f'Read failed: {e}') from e

    def query(self, cmd: str, *, delay_s: float = 0.0) -> str:
        try:
            if delay_s:
                self._res.write(cmd)
                time.sleep(delay_s)
                return self._res.read()
            return self._res.query(cmd)
        except Exception as e:
            raise VisaError(f'Query failed for {cmd!r}: {e}') from e

    @property
    def resource_name(self) -> str:
        return getattr(self._res, 'resource_name', '<unknown>')

    def clear(self) -> None:
        try:
            self._res.clear()
        except Exception:
            pass


__all__ = ['VisaTransport']
