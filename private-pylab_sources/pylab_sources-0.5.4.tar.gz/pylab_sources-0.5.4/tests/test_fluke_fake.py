import json

from pylab_sources.fluke import Fluke6105A
from pylab_sources.fluke.cli import main as fluke_cli_main
from pylab_sources.fluke.events import load_sequence_from_json, run_sequence
from pylab_sources.visa_shim import FakeResourceManager


def test_fake_open_roundtrip():
    instrument = Fluke6105A.open(
        "FLUKE::VIRTUAL",
        resource_manager=FakeResourceManager(),
        timeout_ms=2000,
    )
    try:
        instrument.set_frequency(60.0)
        assert instrument.get_frequency() == 60.0
        plan = [
            {"action": "set_voltage", "phase": "P1", "value": 120.0},
            {"action": "set_voltage_phase", "phase": "P1", "value": 0.0},
        ]
        steps = load_sequence_from_json(plan)
        run_sequence(instrument, steps, simulate_only=True)
    finally:
        instrument.close()


def test_cli_dry_run(tmp_path, capsys):
    plan = [{"action": "set_voltage", "phase": "P1", "value": 120.0}]
    plan_path = tmp_path / "plan.json"
    plan_path.write_text(json.dumps(plan), encoding="utf-8")

    exit_code = fluke_cli_main(
        [
            "seq",
            "run",
            str(plan_path),
            "--backend",
            "fake",
            "--dry-run",
        ]
    )

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "set_voltage" in captured.out
