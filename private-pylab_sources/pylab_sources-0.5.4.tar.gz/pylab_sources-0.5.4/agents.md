# Agents Guide

This document describes how AI coding agents (Codex, Claude, etc.) should behave in this repository.

## 1. Compatibility & API design

- Backwards compatibility is **not required**.
- You may:
  - Change or remove public APIs.
  - Update function signatures and classes.
  - Move code between modules.
- When you change an API, you **must** update all call sites.
- Do **not** add compatibility layers, wrappers, or shims unless explicitly asked.

## 2. Error handling & fallbacks

- We prefer **fail fast** behavior.
- Do **not**:
  - Add silent fallbacks.
  - Catch broad exceptions to “make errors go away”.
  - Guess at missing configuration or inputs.
- Do:
  - Raise clear, descriptive exceptions when something is wrong.
  - Surface problems instead of hiding them.
  - Update all call sites when changing APIs.

## 3. Review yml
- after modifying yml files for github actions:
  - re-review all changes and syntax to avoid upstream errors in github.
  - report the status of the review. 

## 4. Tests

- After modifying Python code:
  - If a test suite exists, run `pytest` from the project root.
  - If tests fail, fix the underlying issue instead of weakening tests.
- If no tests exist for new behavior, consider adding at least a small test.

## 5. Code style & structure

- Follow existing patterns, naming, and module layout.
- Prefer adding type hints and docstrings when extending or creating functions.
- Remove dead code rather than commenting it out.