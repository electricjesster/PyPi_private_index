from typing import Dict, Literal

PhaseName = Literal['P1','P2','P3']
PhaseDict = Dict[PhaseName, float]
