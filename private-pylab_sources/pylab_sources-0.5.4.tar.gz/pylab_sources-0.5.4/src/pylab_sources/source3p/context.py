from __future__ import annotations

from typing import Set

from colorama import Fore, Style
from colorama import init as colorama_init

from .strategy import Capability, SourceStrategy

colorama_init(strip=False, convert=False)

RESET = Style.RESET_ALL
BWHITE = Style.BRIGHT + getattr(Fore, "WHITE", "")
NWHITE = getattr(Fore, "WHITE", "")
BBLUE = Style.BRIGHT + getattr(Fore, "BLUE", "")
NBLUE = getattr(Fore, "BLUE", "")
NMAGENTA = getattr(Fore, "MAGENTA", "")
BYEL = Style.BRIGHT + getattr(Fore, "YELLOW", "")
BGREEN = Style.BRIGHT + getattr(Fore, "GREEN", "")
BRED = Style.BRIGHT + getattr(Fore, "RED", "")
NGREY = getattr(Fore, "LIGHTBLACK_EX", "")


def print_verbose(msg: str):
    """
    @brief Print verbose message

    @param msg (str) Input parameter.

    @returns Value or None.
    """

    print(f"\t{NMAGENTA}[src_3ph]{RESET} {NGREY}{msg}{RESET}")

class SourceContext:
    """
    Lightweight façade over a concrete 3-phase source *strategy*.

    Why a façade?
    - Lets higher layers accept a SourceContext without caring which concrete
      strategy is inside (Fluke, Yoko, Fake).
    - Exposes the same low-level primitives as the strategies themselves,
      so code like `ops.balanced_3ph(src_ctx, ...)` can call methods directly.

    The underlying strategy is available via the public `.strategy` attribute
    and `get_strategy()` for maximum compatibility.
    """

    def __init__(self, strategy: SourceStrategy, *, verbose: bool = False):
        if strategy is None:
            raise ValueError("SourceContext requires a non-None strategy")
        # Public on purpose: ops and call-sites can use ctx.strategy if desired
        self.strategy = strategy
        self.verbose = bool(verbose)

    # ---------------- lifecycle ---------------- #

    def open(self) -> None:
        self.strategy.open()

    def close(self) -> None:
        try:
            self.strategy.close()
        except Exception:
            # Don't let close raise during best-effort cleanup
            pass

    # ---------------- basic control ------------- #

    def on(self) -> None:
        self.strategy.on()

    def off(self) -> None:
        self.strategy.off()

    def all_off(self) -> None:
        # Best effort: allow strategies that may not implement one of these
        try:
            self.strategy.all_off()
        finally:
            try:
                self.strategy.apply()
            except Exception:
                pass

    def apply(self) -> None:
        # Some strategies are immediate-apply; that’s fine.
        try:
            self.strategy.apply()
        except AttributeError:
            pass

    # --------------- per-phase primitives -------- #

    def set_frequency(self, freq_hz: float) -> None:
        if self.verbose:
            print_verbose(f"[src_3ph] Setting frequency to {freq_hz} Hz")
        self.strategy.set_frequency(float(freq_hz))

    def set_phase_voltage(self, phase: str, voltage_v: float) -> None:
        if self.verbose:
            print_verbose(
    f"[src_3ph] Setting phase {phase} voltage to {voltage_v} V")
        self.strategy.set_phase_voltage(phase, float(voltage_v))

    def set_phase_current(self, phase: str, current_a: float) -> None:
        if self.verbose:
            print_verbose(
    f"[src_3ph] Setting phase {phase} current to {current_a} A")
        self.strategy.set_phase_current(phase, float(current_a))

    def set_phase_voltage_angle(self, phase: str, angle_deg: float) -> None:
        # Not all strategies support voltage angle; let strategy raise if
        # needed
        if self.verbose:
            print_verbose(
    f"[src_3ph] Setting phase {phase} voltage angle to {angle_deg} deg")
        self.strategy.set_phase_voltage_angle(phase, float(angle_deg))

    def set_phase_current_angle(self, phase: str, angle_deg: float) -> None:
        # Not all strategies support current angle; let strategy raise if
        # needed
        if self.verbose:
            print_verbose(
    f"[src_3ph] Setting phase {phase} current angle to {angle_deg} deg")
        self.strategy.set_phase_current_angle(phase, float(angle_deg))

    def set_phase(
        self,
        phase: str,
        voltage_v: float,
        voltage_angle_deg: float,
        current_a: float,
        current_angle_deg: float,
    ) -> None:
        self.set_phase_voltage(phase, voltage_v)
        self.set_phase_current(phase, current_a)
        self.set_phase_voltage_angle(phase, voltage_angle_deg)
        self.set_phase_current_angle(phase, current_angle_deg)

    def set_phase_vfa(self, phase: str, voltage_v: float,
                      freq_hz: float, angle_deg: float) -> None:
        if self.verbose:
            print_verbose(
    f"[src_3ph] Setting phase {phase} V={voltage_v}V, F={freq_hz}Hz, A={angle_deg}deg")
        self.strategy.set_phase_vfa(phase, voltage_v, freq_hz, angle_deg)


    # --------------- capabilities ---------------- #

    def capabilities(self) -> Set[Capability]:
        try:
            caps = self.strategy.capabilities()
            return caps if isinstance(caps, set) else set()
        except Exception:
            return set()

    # --------------- helpers --------------------- #

    def get_strategy(self):
        """Convenience accessor used by some unwrapping code."""
        return self.strategy
