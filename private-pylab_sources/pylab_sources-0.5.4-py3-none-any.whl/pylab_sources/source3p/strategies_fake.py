# pylab_sources/source3p/strategies_fake.py
from __future__ import annotations

from typing import Dict, Set

from .strategy import Capability, SourceStrategy


class FakeStrategy(SourceStrategy):
    """
    A no-op 3-phase source for dry runs and testing.

    Implements the full strategy surface so higher layers can call
    the same ops regardless of the real hardware underneath.
    """

    def __init__(self, *, verbose: bool = False):
        # Minimal internal state (purely informational; useful for debugging)
        self._verbose = bool(verbose)
        self._on: bool = False
        self._freq: float = 50.0
        self._v: Dict[int, float] = {1: 0.0, 2: 0.0, 3: 0.0}
        self._i: Dict[int, float] = {1: 0.0, 2: 0.0, 3: 0.0}
        self._vang: Dict[int, float] = {1: 0.0, 2: -120.0, 3: 120.0}
        self._iang: Dict[int, float] = {1: 0.0, 2: -120.0, 3: 120.0}
        # Mapping from strategy phase identifiers (P1 P2 etc) to what the
        # driver wants
        self._phase_map = {'P1': 1, 'P2': 2, 'P3': 3}

    # -------- lifecycle --------
    def open(self) -> None:
        return

    def close(self) -> None:
        return

    # -------- output control --------
    def on(self) -> None:
        self._on = True

    def off(self) -> None:
        self._on = False

    def all_off(self) -> None:
        for p in (1, 2, 3):
            self._v[p] = 0.0
            self._i[p] = 0.0

    def apply(self) -> None:
        # immediate-apply semantics in fake as well
        return

    # -------- primitives --------
    def set_frequency(self, freq_hz: float) -> None:
        self._freq = float(freq_hz)

    def set_phase_voltage(self, phase: str, voltage_v: float) -> None:
        self._v[self._phase_map[phase]] = float(voltage_v)

    def set_phase_current(self, phase: str, current_a: float) -> None:
        self._i[self._phase_map[phase]] = float(current_a)

    def set_phase_voltage_angle(self, phase: str, angle_deg: float) -> None:
        self._vang[self._phase_map[phase]] = float(angle_deg)

    def set_phase_current_angle(self, phase: str, angle_deg: float) -> None:
        self._iang[self._phase_map[phase]] = float(angle_deg)

    # -------- convenience required by abstract base --------
    def set_phase_vfa(self, phase: str, voltage_v: float,
                      freq_hz: float, angle_deg: float) -> None:
        """
        Convenience that some call-sites still use. Mirrors the real strategies.
        """
        self.set_frequency(freq_hz)
        self.set_phase_voltage(phase, voltage_v)
        # In the fake we allow voltage angle; real strategies may raise if
        # unsupported
        self.set_phase_voltage_angle(phase, angle_deg)

    # -------- capabilities --------
    def capabilities(self) -> Set[Capability]:
        # Advertise the full set so PF shaping etc. won't bail out when faking
        return {
            Capability.ThreePhase,
            Capability.VoltageAmplitude,
            Capability.CurrentAmplitude,
            Capability.VoltagePhaseAngle,
            Capability.CurrentPhaseAngle,
            Capability.Frequency,
            Capability.ImmediateApply,
        }
