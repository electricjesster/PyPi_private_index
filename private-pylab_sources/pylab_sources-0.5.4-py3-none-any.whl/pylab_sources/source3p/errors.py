class UnsupportedFeatureError(RuntimeError):
    pass
