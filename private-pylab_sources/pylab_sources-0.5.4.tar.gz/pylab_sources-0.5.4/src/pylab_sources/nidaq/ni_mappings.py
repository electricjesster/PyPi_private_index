# pylab_sources/nidaq/ni_mappings.py
"""
Reference mappings for a 2-module NI-9262 setup in a cDAQ-9124 chassis.

Edit these to match your actual device names in NI MAX. Keys are logical:
  "V:Pn" for voltage phase n (P1,P2,P3), "I:Pn" for current phase n.

Examples assume:
  - Voltages on cDAQ1Mod1 ao0..ao2
  - Currents on  cDAQ1Mod2 ao0..ao2
"""

# Default mapping for a single-chassis system named cDAQ1
NI9262_DEFAULT_MAP = {
    "V:P1": "cDAQ1Mod1/ao0",
    "V:P2": "cDAQ1Mod1/ao1",
    "V:P3": "cDAQ1Mod1/ao2",
    "I:P1": "cDAQ1Mod2/ao0",
    "I:P2": "cDAQ1Mod2/ao1",
    "I:P3": "cDAQ1Mod2/ao2",
}

# Alternate example if modules are swapped
NI9262_ALT_MAP = {
    "V:P1": "cDAQ1Mod2/ao0",
    "V:P2": "cDAQ1Mod2/ao1",
    "V:P3": "cDAQ1Mod2/ao2",
    "I:P1": "cDAQ1Mod1/ao0",
    "I:P2": "cDAQ1Mod1/ao1",
    "I:P3": "cDAQ1Mod1/ao2",
}

# Preferred operating envelope for this project
FREQUENCY_RANGE_HZ = (42.0, 69.0)
SAMPLES_PER_CYCLE  = 4096  # nominal; fs = N*f must be <= 1.0e6 S/s on NI-9262
MAX_FS_PER_CH      = 1_000_000.0
