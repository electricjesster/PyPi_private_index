from ..visa_shim import VisaError
from ..visa_shim.transport import VisaTransport


class SCPIInstrument:
    def __init__(self, transport: VisaTransport): 
        self.io = transport
    def idn(self)->str: 
        return self.io.query('*IDN?').strip()
    def reset(self)->None: 
        self.io.write('*RST')
    def clear_status(self)->None: 
        self.io.write('*CLS')
    def wait_opc(self)->None: 
        self.io.query('*OPC?')
    def error_next(self)->str:
        try:
            return self.io.query('SYST:ERR?').strip()
        except VisaError:
            return '0,"No error"'
    def error_all(self)->list[str]:
        errs=[]
        while True:
            e=self.error_next()
            errs.append(e)
            if e.startswith('0'):
                break
        return errs
    def write(self, cmd:str)->None: 
        self.io.write(cmd)
    def query(self, cmd:str)->str: 
        return self.io.query(cmd).strip()
    @classmethod
    def open(cls, resource_name:str, **kwargs)->'SCPIInstrument':
        tr = VisaTransport.open(resource_name, **kwargs)
        return cls(tr)
    def close(self)->None: 
        self.io.close()
