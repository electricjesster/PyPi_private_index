import pytest

from pylab_sources.source3p import ops
from pylab_sources.source3p.context import SourceContext
from pylab_sources.source3p.strategies_fake import FakeStrategy


@pytest.fixture
def fake_ctx():
    strat = FakeStrategy()
    ctx = SourceContext(strat)
    return ctx, strat


def test_single_phase_programs_explicit_angles(fake_ctx):
    ctx, strat = fake_ctx
    ops.single_phase(
        ctx,
        voltage_v=120.0,
        current_a=5.0,
        freq_hz=60.0,
        v_phase_deg=15.0,
        i_phase_deg=-45.0,
        phase='P1',
    )

    assert pytest.approx(strat._freq, rel=0, abs=1e-9) == 60.0
    assert strat._v[1] == pytest.approx(120.0)
    assert strat._i[1] == pytest.approx(5.0)
    assert strat._vang[1] == pytest.approx(15.0)
    assert strat._iang[1] == pytest.approx(-45.0)
    assert strat._v[2] == pytest.approx(0.0)
    assert strat._i[2] == pytest.approx(0.0)


def test_balanced_3ph_respects_current_angle_map(fake_ctx):
    ctx, strat = fake_ctx
    v_angles = {'P1': 0.0, 'P2': -120.0, 'P3': 120.0}
    i_angles = {'P1': -60.0, 'P2': -180.0, 'P3': 60.0}

    ops.balanced_3ph(
        ctx,
        voltage_v=230.0,
        current_a=10.0,
        freq_hz=50.0,
        v_angles_deg=v_angles,
        i_angles_deg=i_angles,
    )

    assert strat._freq == pytest.approx(50.0)
    for phase, idx in strat._phase_map.items():
        assert strat._v[idx] == pytest.approx(230.0)
        assert strat._i[idx] == pytest.approx(10.0)
        assert strat._vang[idx] == pytest.approx(v_angles[phase])
        assert strat._iang[idx] == pytest.approx(i_angles[phase])


def test_balanced_3ph_defaults_currents_to_voltage_angles(fake_ctx):
    ctx, strat = fake_ctx
    v_angles = {'P1': 10.0, 'P2': -110.0, 'P3': 130.0}

    ops.balanced_3ph(
        ctx,
        voltage_v=100.0,
        current_a=2.0,
        freq_hz=55.0,
        v_angles_deg=v_angles,
    )

    for phase, idx in strat._phase_map.items():
        assert strat._vang[idx] == pytest.approx(v_angles[phase])
        assert strat._iang[idx] == pytest.approx(v_angles[phase])
