from __future__ import annotations

from colorama import Fore, Style
from colorama import init as colorama_init

from ..yokogawa import ThreePhaseLS3300Virtual as ThreePhaseLS3300
from .strategy import Capability, SourceStrategy

colorama_init(strip=False, convert=False)

RESET = Style.RESET_ALL
BYEL = Style.BRIGHT + getattr(Fore, "YELLOW", "")
NGREY = getattr(Fore, "LIGHTBLACK_EX", "")


def _print_verbose(tag: str, msg: str) -> None:
    print(f"\t{BYEL}[{tag}]{RESET} {NGREY}{msg}{RESET}")

class Yokogawa3PhaseStrategy(SourceStrategy):
    """
    Strategy wrapper around your ThreePhaseLS3300 aggregator (3× LS3300).

    Important limitation:
    - LS3300 exposes a single 'phase' per channel; it does not distinguish
      voltage vs current phase angles independently. We implement both setters
      by calling the same underlying 'set_phase(...)'. If a higher-level op
      needs independent V/I angle control (i.e., PF shaping), it must gate on
      capabilities() and return an 'unsupported equipment functionality' error.
    """

    def __init__(self, p1_visa: str, p2_visa: str,
                 p3_visa: str, *, verbose: bool = False):
        self._visas = {"P1": p1_visa, "P2": p2_visa, "P3": p3_visa}
        self._verbose = bool(verbose)
        self._drv: ThreePhaseLS3300 | None = None
        # Mapping from strategy phase identifiers (P1 P2 etc) to what the
        # driver wants
        self._phase_map = {'P1': 'P1', 'P2': 'P2', 'P3': 'P3'}

    # ----- lifecycle -----
    def open(self) -> None:
        self._drv = ThreePhaseLS3300(
            self._visas["P1"],
            self._visas["P2"],
            self._visas["P3"],
            verbose=self._verbose,
        )
        self._drv.open()
        try:
            self.all_off()
            self.off()
        except Exception:
            pass

    def close(self) -> None:
        if self._drv is not None:
            try:
                self.off()
                self.all_off()
            except Exception:
                pass
            try:
                self._drv.close_all()
            finally:
                self._drv = None

    # ----- basic control -----
    def on(self) -> None:
        self._require()
        self._drv.on()  # type: ignore[union-attr]

    def off(self) -> None:
        self._require()
        self.all_off()  # type: ignore[union-attr]

    def all_off(self) -> None:
        self._require()
        # zero all three phases
        # type: ignore[union-attr]
        self._drv.set_phase_voltage({"P1": 0.0, "P2": 0.0, "P3": 0.0})
        # type: ignore[union-attr]
        self._drv.set_phase_current({"P1": 0.0, "P2": 0.0, "P3": 0.0})
        self._drv.on(False)  # type: ignore[union-attr]

    # ----- frequency & per-phase primitives -----
    def set_frequency(self, freq_hz: float) -> None:
        self._require()
        if self._verbose:
            _print_verbose("yoko3p", f"Setting frequency to {freq_hz:.9g} Hz")
        self._drv.set_frequency(float(freq_hz))  # type: ignore[union-attr]

    def set_phase_voltage(self, phase: str, voltage_v: float) -> None:
        self._require()
        ph = self._phase_map[phase]
        if self._verbose:
            _print_verbose(
    "yoko3p",
    f"Setting phase {phase} voltage to {
        voltage_v:.9g} V")
        # type: ignore[union-attr]
        self._drv.set_phase_voltage({ph: float(voltage_v)})

    def set_phase_current(self, phase: str, current_a: float) -> None:
        self._require()
        ph = self._phase_map[phase]
        if self._verbose:
            _print_verbose(
    "yoko3p",
    f"Setting phase {phase} current to {
        current_a:.9g} A")
        # type: ignore[union-attr]
        self._drv.set_phase_current({ph: float(current_a)})

    def set_phase_voltage_angle(self, phase: str, angle_deg: float) -> None:
        self._require()
        ph = self._phase_map[phase]
        if self._verbose:
            _print_verbose(
    "yoko3p",
    f"Setting phase {phase} voltage angle to {
        angle_deg:.9g} deg")
        self._drv.set_phase_voltage_angle(
            {ph: float(angle_deg)})  # type: ignore[union-attr]

    def set_phase_current_angle(self, phase: str, angle_deg: float):
        self._require()
        ph = self._phase_map[phase]
        if self._verbose:
            _print_verbose(
    "yoko3p",
    f"Setting phase {phase} current angle to {
        angle_deg:.9g} deg")
        self._drv.set_phase_current_angle({ph: float(angle_deg)})

    def apply(self) -> None:
        # LS3300 applies immediately; keep for interface parity
        return

    # ----- convenience (compat with earlier helpers) -----
    def set_phase_vfa(self, phase: str, voltage_v: float,
                      freq_hz: float, angle_deg: float) -> None:
        self.set_frequency(freq_hz)
        self.set_phase_voltage(phase, voltage_v)
        self.set_phase_voltage_angle(phase, angle_deg)

    # ----- capabilities -----
    def capabilities(self) -> set[Capability]:
        return {
            Capability.ThreePhase,
            Capability.VoltageAmplitude,
            Capability.CurrentAmplitude,
            Capability.Frequency,
            Capability.ImmediateApply,
            Capability.VoltagePhaseAngle,
            Capability.CurrentPhaseAngle,
            # Note: no independent Current/Voltage phase capability
        }

    # ----- helpers -----
    def _require(self) -> None:
        if self._drv is None:
            raise RuntimeError("Yokogawa3PhaseStrategy not opened yet")
