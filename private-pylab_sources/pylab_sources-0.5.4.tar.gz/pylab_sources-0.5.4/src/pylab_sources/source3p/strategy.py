from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum, auto
from typing import Iterable

from .errors import UnsupportedFeatureError


class Capability(Enum):
    ThreePhase = auto()
    VoltageAmplitude = auto()
    CurrentAmplitude = auto()
    VoltagePhaseAngle = auto()
    CurrentPhaseAngle = auto()
    Frequency = auto()
    ImmediateApply = auto()

class SourceStrategy(ABC):
    @abstractmethod
    def open(self) -> None: ...
    @abstractmethod
    def close(self) -> None: ...
    @abstractmethod
    def all_off(self) -> None: ...
    @abstractmethod
    def on(self) -> None: ...
    @abstractmethod
    def off(self) -> None: ...
    @abstractmethod
    def set_phase_vfa(
    self,
    phase: str,
    voltage_v: float,
    freq_hz: float,
     angle_deg: float) -> None: ...
    
    @abstractmethod
    def set_phase_current(self, phase: str, angle_deg: float)->None: ...
    @abstractmethod
    def set_phase_voltage(self, phase: str, voltage_v: float) -> None: ...
    @abstractmethod
    def set_phase_voltage_angle(
    self, phase: str, angle_deg: float) -> None: ...
    @abstractmethod
    def set_phase_current_angle(
    self, phase: str, angle_deg: float) -> None: ...
    @abstractmethod
    def set_frequency(self, f_hz: float) -> None: ...
    
    # Optional features
    def set_pf(self, pf: float, convention: str = "IEEE") -> None:
        raise UnsupportedFeatureError("set_pf not supported")

    def capabilities(self) -> Iterable[Capability]:
        return []
