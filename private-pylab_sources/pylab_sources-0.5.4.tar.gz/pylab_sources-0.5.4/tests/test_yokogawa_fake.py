import math

from pylab_sources.yokogawa import SinglePhaseLS3300, ThreePhaseLS3300Virtual


def test_single_phase_fake_voltage_current_roundtrip():
    dev = SinglePhaseLS3300("FAKE::YOKO")
    dev.open()
    try:
        dev.set_phase_voltage(150.0)
        dev.set_phase_voltage_angle(15.0)
        dev.set_phase_current(5.0)
        dev.set_phase_current_angle(-10.0)
        dev.set_frequency(55.0)
        dev.output_on(True)

        assert math.isclose(dev.get_phase_voltage(), 150.0)
        assert math.isclose(dev.get_phase_voltage_angle(), 15.0)
        assert math.isclose(dev.get_phase_current(), 5.0)
        assert math.isclose(dev.get_phase_current_angle(), -10.0)
        assert math.isclose(dev.get_frequency(), 55.0)
        assert dev.get_voltage_range() >= 150.0
        assert dev.get_current_range() >= 5.0
    finally:
        dev.close()


def test_three_phase_virtual_controls_all_phases():
    virtual = ThreePhaseLS3300Virtual("FAKE::YOKO1", "FAKE::YOKO2", "FAKE::YOKO3")
    virtual.open()
    try:
        virtual.set_frequency(60.0)
        virtual.set_phase_voltage({"P1": 120.0, "P2": 118.0, "P3": 119.0})
        virtual.set_phase_voltage_angle({"P1": 0.0, "P2": -120.0, "P3": 120.0})
        virtual.set_phase_current(10.0)
        virtual.set_phase_current_angle({"P1": 0.0, "P2": -120.0, "P3": 120.0})

        phases = virtual.idn()
        assert len(phases) == 3
    finally:
        virtual.close_all()
