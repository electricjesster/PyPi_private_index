"""Bridge strategy for NI-9262 that conforms to SourceStrategy and can be constructed
via SourceFactory(kind='nidaq'). This simply re-exports the concrete implementation.
"""

from __future__ import annotations

from ..nidaq.strategies_ni9262 import Ni9262Strategy as _Impl

__all__ = ["NiDAQStrategy"]


class NiDAQStrategy(_Impl):  # type: ignore[misc]
    """Thin alias for pylab_sources.nidaq.Ni9262Strategy."""

    pass
