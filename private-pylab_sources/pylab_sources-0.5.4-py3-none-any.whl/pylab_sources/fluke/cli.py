from __future__ import annotations

import argparse
import os
from typing import Optional

from ..visa_shim import FakeResourceManager
from .events import (
    load_sequence_from_csv,
    load_sequence_from_json,
    plan_sequence,
    run_sequence,
)
from .fluke6105a import Fluke6105A


def _open_inst(
    backend: str, resource: Optional[str], timeout_ms: int) -> Fluke6105A:
    backend = backend.lower()
    if backend not in {"auto", "real", "fake"}:
        raise SystemExit(f"Unsupported backend: {backend}")

    virtual_tag = "FLUKE::VIRTUAL"
    if backend == "fake":
        return Fluke6105A.open(
            virtual_tag,
            resource_manager=FakeResourceManager(),
            timeout_ms=timeout_ms,
        )

    try:  # pragma: no cover - dependency presence check
        import pyvisa  # type: ignore  # noqa: F401

        has_pyvisa = True
    except Exception:
        has_pyvisa = False

    if backend == "real" and not has_pyvisa:
        raise SystemExit(
            "Backend 'real' requested but pyvisa is not installed.")

    if backend == "auto" and not has_pyvisa:
        return Fluke6105A.open(
            virtual_tag,
            resource_manager=FakeResourceManager(),
            timeout_ms=timeout_ms,
        )

    visa_res = resource or os.environ.get("FLUKE_6105A_RESOURCE")
    if not visa_res:
        if backend == "real":
            raise SystemExit(
                "Provide --resource or set FLUKE_6105A_RESOURCE for real backend."
            )
        return Fluke6105A.open(
            virtual_tag,
            resource_manager=FakeResourceManager(),
            timeout_ms=timeout_ms,
        )
    return Fluke6105A.open(visa_res, timeout_ms=timeout_ms)


def _infer_steps(path: str):
    p = path.lower()
    if p.endswith(".json"):
        return load_sequence_from_json(path)
    if p.endswith(".csv"):
        return load_sequence_from_csv(path)
    try:
        return load_sequence_from_json(path)
    except Exception:
        return load_sequence_from_csv(path)


def _summarize_one_step(step: dict) -> str:
    try:
        txt = plan_sequence([step]).splitlines()[0]
        if txt[:3].endswith("."):
            return txt[3:].strip()
        return txt
    except Exception:
        return str(step)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="fluke6105a",
        description="Fluke 6105A CLI",
    )
    subparsers = parser.add_subparsers(dest="cmd")
    p_seq = subparsers.add_parser("seq", help="Sequence operations")
    sp = p_seq.add_subparsers(dest="seq_cmd")
    p_run = sp.add_parser("run", help="Run a sequence (JSON/CSV)")
    p_run.add_argument("file", help="Path to sequence file (.json or .csv)")
    p_run.add_argument(
        "--backend",
        choices=["auto", "real", "fake"],
        default="auto",
        help="Transport backend (default: auto)",
    )
    p_run.add_argument(
        "--resource",
        default=None,
        help="VISA resource for real backend (or FLUKE_6105A_RESOURCE env)",
    )
    p_run.add_argument(
    "--timeout-ms",
    type=int,
    default=5000,
     help="I/O timeout (ms)")
    p_run.add_argument(
        "--simulate-only",
        action="store_true",
        help="Run sequence without sleeps/ramping delays",
    )
    p_run.add_argument(
        "--dry-run",
        action="store_true",
        help="Print execution plan and exit",
    )
    p_run.add_argument(
        "--verbose",
        action="store_true",
        help="Log each step as it executes",
    )
    args = parser.parse_args(argv)

    if args.cmd == "seq" and args.seq_cmd == "run":
        steps = _infer_steps(args.file)
        if args.dry_run:
            print(plan_sequence(steps))
            return 0
        inst = _open_inst(args.backend, args.resource, args.timeout_ms)
        try:
            simulate = args.simulate_only
            if not args.simulate_only and args.backend in {"fake", "auto"}:
                resource_name = getattr(inst.io, "resource_name", "")
                if resource_name in {"FLUKE::VIRTUAL",
                    "FLUKE:VIRTUAL", "FAKE::INSTR"}:
                    simulate = True
            if args.verbose:
                print("=== Execution plan (verbose) ===")
                print(plan_sequence(steps))

                def _on_step(idx: int, step: dict) -> None:
                    print(f"[step {idx:02d}] {_summarize_one_step(step)}")

                run_sequence(
    inst,
    steps,
    simulate_only=simulate,
     on_step=_on_step)
            else:
                run_sequence(inst, steps, simulate_only=simulate)
            return 0
        finally:
            try:
                inst.close()
            except Exception:
                pass

    parser.print_help()
    return 2
