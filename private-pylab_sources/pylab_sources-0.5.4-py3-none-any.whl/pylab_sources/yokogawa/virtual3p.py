from __future__ import annotations

from .single import SinglePhaseLS3300


class ThreePhaseLS3300Virtual:
    """Compose three single-phase LS3300s into a virtual 3-phase source.

    This wrapper does *not* add hardware phase-lock; it simply forwards
    commands to three instruments coherently.
    """
    def __init__(self,
                 res_p1: str,
                 res_p2: str,
                 res_p3: str,
                 timeout_ms: int = 2000,
                 *,
                 verbose: bool = False):
        self._verbose = bool(verbose)
        self.p1 = SinglePhaseLS3300(res_p1, timeout_ms, verbose=self._verbose)
        self.p2 = SinglePhaseLS3300(res_p2, timeout_ms, verbose=self._verbose)
        self.p3 = SinglePhaseLS3300(res_p3, timeout_ms, verbose=self._verbose)

    def open(self):
        self.p1.open()
        self.p2.open()
        self.p3.open()
        return self

    def close_all(self):
        for dev in (self.p1, self.p2, self.p3):
            try:
                dev.close()
            except Exception:
                pass

    # Convenience bulk ops
    def idn(self):
        return (self.p1.idn(), self.p2.idn(), self.p3.idn())

    def on(self, on: bool = True):
        self.p1.set_internal_phase(True)
        self.p2.set_internal_phase(False)
        self.p3.set_internal_phase(False)
        self.p1.output_on(on)
        self.p2.output_on(on)
        self.p3.output_on(on)

    def off(self, off: bool = False):
        self.p1.output_on(off)
        self.p2.output_on(off)
        self.p3.output_on(off)

    def set_frequency(self, freq_hz: float | dict):
        """Set frequency for all or individual phases."""
        if isinstance(freq_hz, dict):
            if "P1" in freq_hz:
                self.p1.set_frequency(freq_hz["P1"])
            if "P2" in freq_hz:
                self.p2.set_frequency(freq_hz["P2"])
            if "P3" in freq_hz:
                self.p3.set_frequency(freq_hz["P3"])
        else:
            self.p1.set_frequency(freq_hz)
            self.p2.set_frequency(freq_hz)
            self.p3.set_frequency(freq_hz)

    def set_phase_voltage(self, voltage_v: float | dict):
        if isinstance(voltage_v, dict):
            if "P1" in voltage_v:
                self.p1.set_phase_voltage(voltage_v["P1"])
            if "P2" in voltage_v:
                self.p2.set_phase_voltage(voltage_v["P2"])
            if "P3" in voltage_v:
                self.p3.set_phase_voltage(voltage_v["P3"])
        else:
            self.p1.set_phase_voltage(voltage_v)
            self.p2.set_phase_voltage(voltage_v)
            self.p3.set_phase_voltage(voltage_v)

    def set_phase_voltage_angle(self, phase_deg: float | dict):
        if isinstance(phase_deg, dict):
            if "P1" in phase_deg:
                self.p1.set_phase_voltage_angle(phase_deg["P1"])
            if "P2" in phase_deg:
                self.p2.set_phase_voltage_angle(phase_deg["P2"])
            if "P3" in phase_deg:
                self.p3.set_phase_voltage_angle(phase_deg["P3"])
        else:
            self.p1.set_phase_voltage_angle(phase_deg)
            self.p2.set_phase_voltage_angle(phase_deg)
            self.p3.set_phase_voltage_angle(phase_deg)

    def set_phase_current(self, current_a: float | dict):
        if isinstance(current_a, dict):
            if "P1" in current_a:
                self.p1.set_phase_current(current_a["P1"])
            if "P2" in current_a:
                self.p2.set_phase_current(current_a["P2"])
            if "P3" in current_a:
                self.p3.set_phase_current(current_a["P3"])
        else:
            self.p1.set_phase_current(current_a)
            self.p2.set_phase_current(current_a)
            self.p3.set_phase_current(current_a)

    def set_phase_current_angle(self, phase_deg: float | dict):
        if isinstance(phase_deg, dict):
            if "P1" in phase_deg:
                self.p1.set_phase_current_angle(phase_deg["P1"])
            if "P2" in phase_deg:
                self.p2.set_phase_current_angle(phase_deg["P2"])
            if "P3" in phase_deg:
                self.p3.set_phase_current_angle(phase_deg["P3"])
        else:
            self.p1.set_phase_current_angle(phase_deg)
            self.p2.set_phase_current_angle(phase_deg)
            self.p3.set_phase_current_angle(phase_deg)
