from colorama import Fore, Style
from colorama import init as colorama_init

colorama_init(strip=False, convert=False)

RESET = Style.RESET_ALL
_CYAN = getattr(Fore, "CYAN", "")
_LIGHTBLACK = getattr(Fore, "LIGHTBLACK_EX", "")
BCYAN = Style.BRIGHT + _CYAN
NGREY = _LIGHTBLACK


def _print_verbose(tag: str, msg: str) -> None:
    print(f"\t  {BCYAN}[{tag}]{RESET} {NGREY}{msg}{RESET}")

class _VisaWrapper:
    """Tiny VISA opener that prefers visa_shim if present, else falls back to pyvisa.
    The returned object must offer .write(str), .query(str) -> str, .close().
    """
    # Get rid of this, it's not needed. Just import visa_shim. If it's not there,
    # something else is very wrong.
    @staticmethod
    def open(resource: str, timeout_ms: int):
        # Try visa_shim (preferred common shim)
        try:
            from ..visa_shim import open_resource as _open_res

            inst = _open_res(resource, timeout_ms=timeout_ms)
            return inst
        except Exception:
            pass
        # Fallback to pyvisa
        try:
            import pyvisa
            rm = pyvisa.ResourceManager()
            inst = rm.open_resource(resource)
            inst.timeout = timeout_ms
            # normalize: add .query if not present
            if not hasattr(inst, "query"):
                def _query(cmd: str):
                    inst.write(cmd)
                    return inst.read()
                inst.query = _query
            return inst
        except Exception as e:
            raise RuntimeError(
                f"Unable to open VISA resource '{resource}': {e}"
            ) from e


class LS3300Session:
    """Low-level SCPI session for Yokogawa LS3300.
    Minimal, but centralized so higher-level wrapper stays clean.
    """
    def __init__(self, resource: str, timeout_ms: int = 2000, *,
                 verbose: bool = False):
        self.resource = resource
        self.timeout_ms = timeout_ms
        self.verbose = bool(verbose)
        self._inst = None

    # --- lifecycle ---
    def open(self):
        if self._inst is None:
            self._inst = _VisaWrapper.open(self.resource, self.timeout_ms)
        return self

    def close(self):
        if self._inst is not None:
            try:
                self._inst.close()
            except Exception:
                pass
            self._inst = None

    # --- raw IO ---
    def write(self, cmd: str):
        if not self._inst:
            raise RuntimeError("LS3300Session not open")
        return self._inst.write(cmd)

    def query(self, cmd: str) -> str:
        if not self._inst:
            raise RuntimeError("LS3300Session not open")
        return str(self._inst.query(cmd)).strip()

    # --- convenience ---
    def idn(self) -> str:
        try:
            return self.query("*IDN?")
        except Exception:
            return ""

    def set_voltage_range(self, v_range: float):
        self.write(f":SOURce:VOLTage:RANGe {v_range:.0f}")

    def get_voltage_range(self) -> float:
        return float(self.query(":SOURce:VOLTage:RANGe?"))

    def set_frequency_hz(self, hz: float):
        self.write(f":OSCillator:FREQuency {hz:.6f}")

    def get_frequency_hz(self) -> float:
        return float(self.query(":OSCillator:FREQuency?"))

    def set_voltage_rms(self, v_rms: float):
        self.write(f":SOURce:VOLTage:LEVel:VALue {v_rms:.6f}")

    def set_voltage_phase_deg(self, deg: float):
        self.write(f":SOURce:VOLTage:PHASe:VALue {deg:.6f}")

    def get_phase_voltage_angle(self) -> float:
        return float(self.query(":SOURce:VOLTage:PHASe:VALue?"))

    def output(self, on: bool):
        self.write(f":OUTPut:STATe {'ON' if on else 'OFF'}")

    def enable_voltage_output(self, on: bool):
        self.write(f":OUTPUT:SELEct:VOLTage1 {'ON' if on else 'OFF'}")

    def enable_current_output(self, on: bool):
        self.write(f":OUTPUT:SELEct:CURRent1 {'ON' if on else 'OFF'}")

    def set_voltage_level_ratio(self, ratio: float):
        self.write(f":SOURce:VOLTage:LEVel:RATio {ratio:.6f}")

    def set_current_level_ratio(self, ratio:float):
        self.write(f"SOURce:CURRent:LEVel:RATio {ratio:.6f}")

    def set_current_range(self, i_range: float):
        self.write(f":SOURce:CURRent:RANGe {i_range:.6f}")

    def get_current_range(self) -> float:
        return float(self.query(":SOURce:CURRent:RANGe?"))

    def set_current_rms(self, i_rms: float):
        self.write(f":SOURce:CURRent:LEVel:VALue {i_rms:.6f}")

    def get_current_rms(self) -> float:
        return float(self.query(":SOURce:CURRent:LEVel:VALue?"))

    def get_voltage_rms(self) -> float:
        return float(self.query(":SOURce:VOLTage:LEVel:VALue?"))
    
    def set_current_phase_deg(self, deg: float):
        """
        Set current output (or current sensor signal) phase angle.
        Instrument normalizes into -180 .. +180.
        """
        if not (-181.0 <= deg <= 360.0):
            raise ValueError(
                "Current phase out of allowable input range (-181..360)")
        self.write(f":SOURce:CURRent:PHASe:VALue {deg:.3f}")

    def get_current_phase_deg(self) -> float:
        return float(self.query(":SOURce:CURRent:PHASe:VALue?"))
    
    def set_internal_phase(self, internal_phase: bool):
        self.write(
    f":OSCillator:SOURce {
        'INTernal' if internal_phase else 'EXTernal'}")
    


class SinglePhaseLS3300:
    """Friendly single-phase API over LS3300Session."""

    _VOLTAGE_RANGES = [1, 10, 30, 100, 300, 1000]
    _CURRENT_RANGES = [0.03, 0.1, 1, 10, 50]


    def __init__(self, resource: str, timeout_ms: int = 2000, *,
                 verbose: bool = False):
        self.verbose = bool(verbose)
        self._sess = LS3300Session(resource, timeout_ms, verbose=self.verbose)

    def open(self):
        self._sess.open()
        return self

    def close(self):
        self._sess.close()

    # Basic operations
    def idn(self) -> str: return self._sess.idn()

    def set_phase_vfa(self, freq_hz: float, volts_rms: float,
                      phase_deg: float = 0.0):
        self.set_frequency(freq_hz)
        self.set_phase_voltage(volts_rms)
        self.set_phase_voltage_angle(phase_deg)

    def set_phase_voltage(self, v_rms: float):
        if self.verbose:
            _print_verbose("yoko_1ph", f"Voltage request -> {v_rms:.9g} V")
        voltage_range = None
        for rng in self._VOLTAGE_RANGES:
            if v_rms <= rng * 1.2:
                voltage_range = rng
                break
        else:
            raise ValueError(
    f"Requested voltage {v_rms} V exceeds max output.")
        self._sess.set_voltage_range(voltage_range)
        self._sess.set_voltage_level_ratio(100)
        self._sess.set_voltage_rms(v_rms)
        if self.verbose:
            _print_verbose(
    "yoko_1ph<-",
    f"Voltage programmed {
        v_rms:.9g} V (range {voltage_range} V)")
        

    def set_phase_voltage_angle(self, deg: float):
        if self.verbose:
            _print_verbose("yoko_1ph",
     f"Voltage angle request -> {deg:.9g} deg")
        self._sess.set_voltage_phase_deg(deg)
        if self.verbose:
            _print_verbose(
    "yoko_1ph<-",
    f"Voltage angle programmed {
        deg:.9g} deg")

    def set_frequency(self, hz: float):
        if self.verbose:
            _print_verbose("yoko_1ph", f"Frequency request -> {hz:.9g} Hz")
        self._sess.set_frequency_hz(hz)
        if self.verbose:
            _print_verbose("yoko_1ph<-", f"Frequency programmed {hz:.9g} Hz")
    def output_on(self, on: bool = True):
        self._sess.output(on)
        self._sess.enable_voltage_output(on)
        self._sess.enable_current_output(on)

    def set_phase_current(self, i_rms: float):
        if self.verbose:
            _print_verbose("yoko_1ph", f"Current request -> {i_rms:.9g} A")
        current_range = None
        for rng in self._CURRENT_RANGES:
            if i_rms <= rng * 1.2:
                current_range = rng
                break
        else:
            raise ValueError(
    f"Requested current {i_rms} A exceeds max output.")

        self._sess.set_current_range(current_range)
        self._sess.set_current_level_ratio(100)
        self._sess.set_current_rms(i_rms)
        if self.verbose:
            _print_verbose(
    "yoko_1ph<-",
    f"Current programmed {
        i_rms:.9g} A (range {current_range} A)")

    def get_phase_current(self) -> float: return self._sess.get_current_rms()
    def get_phase_voltage(self) -> float: return self._sess.get_voltage_rms()
    def get_phase_voltage_angle(
        self) -> float: return self._sess.get_phase_voltage_angle()
    def get_frequency(self) -> float: return self._sess.get_frequency_hz()
    def get_voltage_range(self) -> float: return self._sess.get_voltage_range()
    def get_current_range(self) -> float: return self._sess.get_current_range()

    def set_phase_current_angle(self, deg: float):
        if self.verbose:
            _print_verbose("yoko_1ph",
     f"Current angle request -> {deg:.9g} deg")
        self._sess.set_current_phase_deg(deg)
        if self.verbose:
            _print_verbose(
    "yoko_1ph<-",
    f"Current angle programmed {
        deg:.9g} deg")

    def get_phase_current_angle(self) -> float:
        return self._sess.get_current_phase_deg()
    
    def set_internal_phase(self, internal_phase: bool):
        self._sess.set_internal_phase(internal_phase)
