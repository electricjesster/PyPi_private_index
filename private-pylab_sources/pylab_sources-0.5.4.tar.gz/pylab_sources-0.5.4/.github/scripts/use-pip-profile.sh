#!/usr/bin/env bash
# shellcheck shell=bash
set -euo pipefail
PROFILE="${1:-}"
if [ -z "$PROFILE" ]; then
  echo "PIP_INDEX_URL=https://pypi.org/simple" >> "$GITHUB_ENV"
  exit 0
fi
PROFILE_PATH=".github/pip/$PROFILE"
if [ ! -f "$PROFILE_PATH" ]; then
  echo "::error::pip profile '$PROFILE' not found at $PROFILE_PATH" >&2
  exit 1
fi
set -a
source "$PROFILE_PATH"
set +a
if [ -n "${PIP_EXTRA_INDEX_URL:-}" ]; then
  echo "PIP_EXTRA_INDEX_URL=$PIP_EXTRA_INDEX_URL" >> "$GITHUB_ENV"
fi
if [ -n "${PIP_TRUSTED_HOST:-}" ]; then
  echo "PIP_TRUSTED_HOST=$PIP_TRUSTED_HOST" >> "$GITHUB_ENV"
fi
if [ "${PIP_PROFILE_KIND:-}" = "github-packages" ]; then
  if [ -z "${GH_PACKAGES_TOKEN:-}" ]; then
    echo "::error::GH_PACKAGES_TOKEN must be provided for the github-packages profile" >&2
    exit 1
  fi
  OWNER_LC="${GITHUB_REPOSITORY_OWNER,,}"
  echo "PIP_INDEX_URL=https://${GITHUB_ACTOR}:${GH_PACKAGES_TOKEN}@pip.pkg.github.com/${OWNER_LC}/simple" >> "$GITHUB_ENV"
else
  echo "PIP_INDEX_URL=${PIP_INDEX_URL:-https://pypi.org/simple}" >> "$GITHUB_ENV"
fi
