'''
Convienence wrapper to easily set 3phase balanced and single phase source. This is a companion to 
the primitives outlined the strategies.
'''


from __future__ import annotations

from typing import Any, Mapping

# === unwrap the real strategy from any context/wrapper =======================

_UNWRAP_ATTRS = (
    "strategy", "_strategy",
    "impl", "_impl",
    "strat",
    "driver", "drv",
    "delegate", "inner",
)

_PRIMITIVES = (str, bytes, int, float, bool, complex, type(None))

def _looks_like_strategy(obj: Any) -> bool:
    return all(hasattr(obj, m) for m in ("set_frequency",
               "set_phase_voltage", "set_phase_current"))

def _unwrap_strategy(obj: Any) -> Any:
    """
    Accept a SourceContext (or any wrapper) OR a raw strategy and return the
    low-level strategy.
    """
    seen: set[int] = set()
    stack: list[Any] = [obj]
    while stack:
        cur = stack.pop()
        if _looks_like_strategy(cur):
            return cur
        ident = id(cur)
        if ident in seen:
            continue
        seen.add(ident)

        # try known wrapper attributes
        for name in _UNWRAP_ATTRS:
            if hasattr(cur, name):
                try:
                    cand = getattr(cur, name)
                except Exception:
                    continue
                if cand is not None and cand is not cur:
                    stack.append(cand)

        # try a getter
        if hasattr(cur, "get_strategy"):
            try:
                cand = cur.get_strategy()
                if cand is not None and cand is not cur:
                    stack.append(cand)
            except Exception:
                pass

        # scan __dict__ values
        d = getattr(cur, "__dict__", None)
        if isinstance(d, dict):
            for v in d.values():
                if v is not None and not isinstance(
                    v, _PRIMITIVES) and v is not cur:
                    stack.append(v)

        # scan public attrs (properties)
        for name in dir(cur):
            if name.startswith(
                "__") or name in _UNWRAP_ATTRS or name == "get_strategy":
                continue
            try:
                v = getattr(cur, name)
            except Exception:
                continue
            if callable(v):
                continue
            if v is not None and not isinstance(
                v, _PRIMITIVES) and v is not cur:
                stack.append(v)

    return obj  # give up; caller will raise a helpful error


# === public operations ==================================================

def all_off(src) -> None:
    s = _unwrap_strategy(src)
    # Best-effort shutdown; ignore missing methods
    for fn in ("off", "all_off", "apply"):
        if hasattr(s, fn):
            try:
                getattr(s, fn)()
            except Exception:
                pass


def single_phase(
    src,
    V: float | None = None,
    I: float | None = None,
    F: float | None = None,
    *,
    voltage_v: float | None = None,
    current_a: float | None = None,
    freq_hz: float | None = None,
    v_phase_deg: float = 0.0,
    i_phase_deg: float = 0.0,
    phase: str = 'P1',
) -> None:
    """Program one phase (default P1) to V/I at F with explicit phase angles."""
    s = _unwrap_strategy(src)

    if not hasattr(s, "set_frequency"):
        raise AttributeError(
    f"source strategy missing set_frequency(); got {
        type(s).__name__}")

    if voltage_v is None:
        if V is None:
            raise TypeError("voltage_v (or legacy V) must be provided")
        voltage_v = V
    if current_a is None:
        if I is None:
            raise TypeError("current_a (or legacy I) must be provided")
        current_a = I
    if freq_hz is None:
        if F is None:
            raise TypeError("freq_hz (or legacy F) must be provided")
        freq_hz = F

    # base magnitudes + frequency
    s.set_frequency(float(freq_hz))
    s.set_phase_voltage(phase, float(voltage_v))
    s.set_phase_current(phase, float(current_a))

    # voltage angle (if supported)
    if hasattr(s, "set_phase_voltage_angle"):
        s.set_phase_voltage_angle(phase, float(v_phase_deg))

    if hasattr(s, "set_phase_current_angle"):
        s.set_phase_current_angle(phase, float(i_phase_deg))

    # apply (no-op on immediate-apply devices)
    if hasattr(s, "apply"):
        s.apply()

    # finally, ensure outputs are enabled
    if hasattr(s, "on"):
        s.on()


def balanced_3ph(
    src,
    V: float | None = None,
    I: float | None = None,
    F: float | None = None,
    *,
    voltage_v: float | None = None,
    current_a: float | None = None,
    freq_hz: float | None = None,
    v_angles_deg: Mapping[str, float] | None = None,
    i_angles_deg: Mapping[str, float] | None = None,
) -> None:
    """Balanced 3-phase: same V/I on P1..P3; explicit phase angles for voltage and current."""
    s = _unwrap_strategy(src)

    if voltage_v is None:
        if V is None:
            raise TypeError("voltage_v (or legacy V) must be provided")
        voltage_v = V
    if current_a is None:
        if I is None:
            raise TypeError("current_a (or legacy I) must be provided")
        current_a = I
    if freq_hz is None:
        if F is None:
            raise TypeError("freq_hz (or legacy F) must be provided")
        freq_hz = F

    phases = ('P1', 'P2', 'P3')

    v_map = {'P1': 0.0, 'P2': -120.0, 'P3': 120.0}
    if v_angles_deg is not None:
        v_map.update({k: float(v_angles_deg[k]) for k in v_angles_deg})
    if any(ph not in v_map for ph in phases):
        raise ValueError(
            "v_angles_deg must provide angles for phases P1, P2, and P3")

    if i_angles_deg is None:
        i_map = dict(v_map)
    else:
        i_map = {k: float(i_angles_deg[k]) for k in i_angles_deg}
        if any(ph not in i_map for ph in phases):
            raise ValueError(
                "i_angles_deg must provide angles for phases P1, P2, and P3")

    if not hasattr(s, "set_frequency"):
        raise AttributeError(
    f"source strategy missing set_frequency(); got {
        type(s).__name__}")

    s.set_frequency(float(freq_hz))

    for phase in phases:
        s.set_phase_voltage(phase, float(voltage_v))
        s.set_phase_current(phase, float(current_a))
        if hasattr(s, "set_phase_voltage_angle"):
            s.set_phase_voltage_angle(phase, float(v_map[phase]))
        if hasattr(s, "set_phase_current_angle"):
            s.set_phase_current_angle(phase, float(i_map[phase]))

    if hasattr(s, "apply"):
        s.apply()

    # finally, ensure outputs are enabled
    if hasattr(s, "on"):
        s.on()
