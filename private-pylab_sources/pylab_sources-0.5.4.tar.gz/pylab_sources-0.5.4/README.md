# pylab-sources

Unified drivers for signal sources within the LabAutomation toolkit. The package is being built out as part of the monorepo refactor and already includes:

- Fluke 6105A instrument driver (`pylab_sources.fluke.Fluke6105A`) with CLI helpers.
- VISA shim abstraction (`pylab_sources.visa_shim`) that provides fake and real backends plus a thin transport layer.
- Yokogawa LS3300 single and virtual three-phase drivers (`pylab_sources.yokogawa`).
- NI-DAQ (NI-9262) strategies (`pylab_sources.nidaq`) with optional hardware and fake implementations (`pip install pylab-sources[nidaq]` for runtime deps).
- Three-phase orchestration context, operations, and strategy factory (`pylab_sources.source3p`).

Upcoming migrations will fold in the higher-level 3-phase orchestration so downstream applications can depend on a single distribution.
