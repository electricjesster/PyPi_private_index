from __future__ import annotations

import csv
import json
from typing import Any, Dict, List, Union


def _to_bool(x: Union[str,bool,int,float,None], default=False) -> bool:
    if isinstance(x, bool):
        return x
    if x is None:
        return default
    s = str(x).strip().lower()
    if s in ("1","true","yes","y","on"):
        return True
    if s in ("0","false","no","n","off"):
        return False
    return default

def load_sequence_from_json(
    obj_or_path: Union[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    if isinstance(obj_or_path, list):
        return obj_or_path
    with open(obj_or_path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_sequence_from_csv(path: str) -> List[Dict[str, Any]]:
    steps: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            step = {k.strip().lower(): v for k,v in row.items()}
            for key in ("value","percent","duration_s","slew_v_per_s","phase_deg","order",
                        "i_rms","v_ll_rms","freq_hz","voltage_phase_reference_deg","nominal_v"):
                if key in step and step[key] not in (None, ""):
                    try:
                        step[key] = float(
    step[key]) if key != "order" else int(
        step[key])
                    except Exception:
                        pass
            if "restore" in step:
                step["restore"] = _to_bool(step["restore"], True)
            if "on" in step:
                step["on"] = _to_bool(step["on"])
            if "angles_deg" in step and step["angles_deg"] not in (None, ""):
                raw = step["angles_deg"]
                if isinstance(raw, str):
                    try:
                        step["angles_deg"] = json.loads(raw)
                    except Exception:
                        try:
                            step["angles_deg"] = [
    float(part) for part in raw.split(',') if part.strip()]
                        except Exception:
                            pass
            steps.append(step)
    return steps

def run_sequence(inst, steps: List[Dict[str, Any]], *,
                 simulate_only: bool = True, on_step=None) -> None:
    import time
    for i, raw in enumerate(steps, start=1):
        step = {k.lower(): v for k,v in raw.items()}
        action = step.get("action") or step.get("type")
        if action is None:
            raise ValueError(f"Step {i}: missing action/type")
        action = str(action).strip().lower()
        if on_step:
            try:
                on_step(i, {k:v for k,v in step.items()})
            except Exception:
                pass
        phase = step.get("phase")
        if isinstance(phase, str) and phase.upper() in ("P1","P2","P3","P4"):
            phase = phase.upper()
        elif phase is not None:
            try:
                phase = int(phase)
            except Exception:
                pass
        if action == "set_voltage":
            inst.set_voltage(phase, float(step["value"]))
        elif action == "set_current":
            inst.set_current(phase, float(step["value"]))
        elif action == "set_frequency":
            inst.set_frequency(float(step["value"]))
        elif action == "set_voltage_phase":
            inst.set_voltage_phase(phase, float(step["value"]))
        elif action == "set_current_phase":
            inst.set_current_phase(phase, float(step["value"]))
        elif action == "dip":
            nominal = float(step.get("nominal_v") or inst.get_voltage(phase))
            inst.apply_voltage_dip(
    phase,
    nominal_v=nominal,
    dip_percent=float(
        step["percent"]),
        duration_s=float(
            step.get("duration_s") or 0.0),
            restore=bool(
                step.get(
                    "restore",
                    True)),
                    simulate_only=simulate_only,
                     slew_v_per_s=step.get("slew_v_per_s"))
        elif action == "swell":
            nominal = float(step.get("nominal_v") or inst.get_voltage(phase))
            inst.apply_voltage_swell(
    phase,
    nominal_v=nominal,
    swell_percent=float(
        step["percent"]),
        duration_s=float(
            step.get("duration_s") or 0.0),
            restore=bool(
                step.get(
                    "restore",
                    True)),
                    simulate_only=simulate_only,
                     slew_v_per_s=step.get("slew_v_per_s"))
        elif action == "harm_clear":
            inst.harm_clear(phase, step.get("kind","VOLT"))
        elif action == "harm_enable":
            inst.harm_enable(
    phase, bool(
        step.get(
            "on", True)), step.get(
                "kind","VOLT"))
        elif action == "harm_add":
            inst.harm_add(
    phase, int(
        step["order"]), float(
            step["percent"]), float(
                step.get(
                    "phase_deg", 0.0)), step.get(
                        "kind","VOLT"))
        elif action == "set_three_phase_system":
            inst.set_three_phase_system(
    v_ll_rms=float(
        step["v_ll_rms"]), freq_hz=float(
            step["freq_hz"]), sequence=str(
                step.get(
                    "sequence","ABC")).upper(), voltage_phase_reference_deg=float(
                        step.get(
                            "voltage_phase_reference_deg",0.0)))
        elif action == "set_three_phase_currents":
            inst.set_three_phase_currents(
                i_rms=float(step["i_rms"]),
                current_angles_deg=step.get("angles_deg"),
            )
        elif action == "wait":
            if not simulate_only:
                time.sleep(float(step.get("duration_s", 0.0)))
        else:
            raise ValueError(f"Unsupported action at step {i}: {action}")

def plan_sequence(steps: List[Dict[str, Any]]) -> str:
    lines = []
    for i, raw in enumerate(steps, start=1):
        step = {k.lower(): v for k, v in raw.items()}
        action = str(step.get("action") or step.get("type") or "").lower()
        phase = step.get("phase", "-")
        if isinstance(phase, str):
            phase = phase.upper()
        if action in ("set_voltage", "set_current"):
            value = step.get("value")
            lines.append(f"{i:02d}. {action} phase={phase} value={value}")
        elif action == "set_frequency":
            lines.append(f"{i:02d}. set_frequency value={step.get('value')}")
        elif action in ("set_voltage_phase", "set_current_phase"):
            value = step.get("value")
            lines.append(f"{i:02d}. {action} phase={phase} value={value} deg")
        elif action in ("dip", "swell"):
            pct = step.get("percent")
            dur = step.get("duration_s")
            slew = step.get("slew_v_per_s")
            nom = step.get("nominal_v")
            nom_txt = f"{nom}" if nom is not None else "<resolve at runtime: current Vrms>"
            lines.append(
                (
                    f"{i:02d}. {action} phase={phase} "
                    f"percent={pct}% duration={dur}s slew={slew} nominal_v={nom_txt}"
                )
            )
        elif action == "harm_clear":
            lines.append(f"{i:02d}. harm_clear phase={phase} kind={step.get('kind') or 'VOLT'}")
        elif action == "harm_enable":
            line = (
                f"{i:02d}. harm_enable phase={phase} "
                f"kind={step.get('kind') or 'VOLT'} on={step.get('on')}"
            )
            lines.append(line)
        elif action == "harm_add":
            lines.append(
                (
                    f"{i:02d}. harm_add phase={phase} "
                    f"kind={step.get('kind') or 'VOLT'} "
                    f"order={step.get('order')} "
                    f"percent={step.get('percent')} "
                    f"phase_deg={step.get('phase_deg')}"
                )
            )
        elif action == "set_three_phase_system":
            lines.append(
                (
                    f"{i:02d}. set_three_phase_system V_LL={step.get('v_ll_rms')}Vrms "
                    f"freq={step.get('freq_hz')}Hz "
                    f"seq={str(step.get('sequence') or 'ABC').upper()} "
                    f"ref_deg={step.get('voltage_phase_reference_deg')}"
                )
            )
        elif action == "set_three_phase_currents":
            line = (
                f"{i:02d}. set_three_phase_currents "
                f"I={step.get('i_rms')}A angles={step.get('angles_deg')}"
            )
            lines.append(line)
        elif action == "wait":
            lines.append(f"{i:02d}. wait {step.get('duration_s')}s")
        else:
            lines.append(f"{i:02d}. {action}  (unrecognized)  raw={raw}")
    return "\n".join(lines)
