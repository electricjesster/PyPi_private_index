import pytest

from pylab_sources.nidaq import Ni9262FakeStrategy


def test_fake_strategy_generates_buffers():
    strat = Ni9262FakeStrategy(samples_per_cycle=128, amplitudes_are_rms=True)
    strat.set_frequency(60.0)
    strat.set_phase_voltage("P1", 120.0)
    strat.set_phase_voltage("P2", 118.0)
    strat.set_phase_voltage("P3", 119.0)
    strat.set_phase_current("P1", 5.0)
    strat.set_phase_current("P2", 4.5)
    strat.set_phase_current("P3", 4.8)
    strat.set_phase_voltage_angle("P2", -120.0)
    strat.set_phase_voltage_angle("P3", 120.0)

    strat.on()
    buffers = strat.last_buffers()
    assert buffers is not None
    phys, data, fs = buffers
    assert pytest.approx(fs, rel=0, abs=1e-6) == strat._freq_hz * strat._N
    assert len(phys["master"]) == len(data["master"])
    assert len(phys["slave"]) == len(data["slave"])
    assert all(len(chan_data) == strat._N for chan_data in data["master"])
    assert all(abs(val) <= 10.0 for chan_data in data["master"] for val in chan_data)
