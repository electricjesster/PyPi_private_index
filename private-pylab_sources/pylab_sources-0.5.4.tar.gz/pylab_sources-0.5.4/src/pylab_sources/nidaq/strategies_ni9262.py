from __future__ import annotations

import math
from typing import TYPE_CHECKING, Dict, Iterable, List, Optional

if TYPE_CHECKING:
    import numpy as _np

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    np = None  # type: ignore[assignment]

try:
    import nidaqmx  # type: ignore
    from nidaqmx.constants import AcquisitionType  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    nidaqmx = None  # type: ignore[assignment]
    AcquisitionType = None  # type: ignore[assignment]

from ..source3p.strategy import Capability, SourceStrategy

# ---- TODO fix scaling ----
V_PK_TO_DAQ = 1.0 / 153.0  
I_PK_TO_DAQ = .8  
_DAQ_LIMIT = 10.0  

_MIN_F_HZ = 42.0
_MAX_F_HZ = 69.0
_MAX_FS = 1_000_000.0  # NI-9262 per-channel max update rate (CompactDAQ)


class Ni9262Strategy(SourceStrategy):

    def __init__(
        self,
        ao_channels: List[str],
        samples_per_cycle: int = 4096,
        amplitudes_are_rms: bool = True,
        *,
        verbose: bool = False,
    ):
        self.ao_channels = ao_channels
        self.samples_per_cycle = samples_per_cycle
        self.amplitudes_are_rms = amplitudes_are_rms
        self.verbose = bool(verbose)
        self.freq_hz = 50.0
        self.voltages: Dict[str, float] = {"P1": 0.0, "P2": 0.0, "P3": 0.0}
        self.currents: Dict[str, float] = {"P1": 0.0, "P2": 0.0, "P3": 0.0}
        self.phases_v: Dict[str, float] = {
            "P1": 0.0, "P2": -120.0, "P3": 120.0}
        self.phases_i: Dict[str, float] = {
            "P1": 0.0, "P2": -120.0, "P3": 120.0}
        # type: ignore[name-defined]
        self.task: Optional["nidaqmx.Task"] = None
        self.data: Optional["_np.ndarray"] = None

    # ------------ control ------------

    def open(self) -> None:
        pass  # TODO?

    def close(self) -> None:
        self.all_off()

    def on(self) -> None:
        self._apply_internal(start=True)

    def all_off(self) -> None:
        if self.task:
            try:
                self.task.stop()
            except Exception:
                pass
            try:
                self.task.close()
            except Exception:
                pass
            self.task = None

    def off(self) -> None:
        self.all_off()

    # ------------ configuration ------------

    def set_phase_vfa(
        self, phase: str, voltage_v: float, freq_hz: float, angle_deg: float
    ) -> None:
        """Set Voltage/Frequency/Angle for a phase (Voltage angle)."""
        self.set_frequency(freq_hz)
        self.set_phase_voltage(phase, voltage_v)
        self.set_phase_voltage_angle(phase, angle_deg)

    # Strategies:
    def set_phase_voltage(self, phase: str, voltage_v: float) -> None:
        self.voltages[phase] = voltage_v

    def set_phase_current(self, phase: str, current_a: float) -> None:
        self.currents[phase] = current_a

    def set_phase_voltage_angle(self, phase: str, angle_deg: float) -> None:
        self.phases_v[phase] = angle_deg 

    def set_phase_current_angle(self, phase: str, angle_deg: float) -> None:
        self.phases_i[phase] = angle_deg + self.phases_v[phase]

    def set_samples_per_cycle(self, N: int) -> None:
        if N <= 0:
            raise ValueError("samples_per_cycle must be > 0")
        self.samples_per_cycle = int(N)

    def set_frequency(self, f_hz: float) -> None:
        f = float(f_hz)
        if not (_MIN_F_HZ <= f <= _MAX_F_HZ):
            raise ValueError(
                f"frequency {f} Hz out of allowed range [{_MIN_F_HZ}, {_MAX_F_HZ}]"
            )
        self.freq_hz = f

    # ------------ identity / capabilities ------------

    def identify(self) -> str:
        channel_count = len(self.ao_channels)
        return (
            "NI-9262 3-phase "
            f"(channels={channel_count}, N={self.samples_per_cycle}, f={self.freq_hz:.2f} Hz)"
        )

    def capabilities(self) -> Iterable[Capability]:
        return {
            Capability.ThreePhase,
            Capability.VoltageAmplitude,
            Capability.CurrentAmplitude,
            Capability.VoltagePhaseAngle,
            Capability.CurrentPhaseAngle,
            Capability.Frequency,
            Capability.ImmediateApply,
        }

    # ------------ internals ------------

    def _to_pk(self, amp_in: float) -> float:
        a = float(amp_in)
        return a * math.sqrt(2.0) if self.amplitudes_are_rms else a

    def _build_waveforms(self) -> "_np.ndarray":
        if np is None:
            raise RuntimeError(
                "numpy is required to build NI-DAQ waveforms; install the 'nidaq' extra.")
        N = self.samples_per_cycle
        fs = self.freq_hz * N
        if fs > _MAX_FS + 1e-6:
            raise ValueError(
                f"Requested fs={
    fs:.1f} S/s exceeds NI-9262 limit {
        _MAX_FS:.0f} S/s; "
                f"reduce samples_per_cycle or frequency"
            )
        k = np.arange(N)
        w = 2.0 * math.pi / N

        phase_signals = [
            ("V", "P1"),
            ("V", "P2"),
            ("V", "P3"),
            ("I", "P1"),
            ("I", "P2"),
            ("I", "P3"),
        ]
        waves = []
        for kind, phase in phase_signals:
            if kind == "V":
                amp_pk = self._to_pk(self.voltages.get(phase, 0.0))
                ang = self.phases_v.get(phase, 0.0)
                scale = V_PK_TO_DAQ
            else:
                amp_pk = self._to_pk(self.currents.get(phase, 0.0))
                ang = self.phases_i.get(phase, 0.0)
                scale = I_PK_TO_DAQ
            phi = math.radians(ang)
            vals = amp_pk * np.sin(w * k + phi) * scale
            clamped = np.clip(vals, -_DAQ_LIMIT, _DAQ_LIMIT)
            waves.append(clamped)
        return np.array(waves)

    def _apply_internal(self, start: bool) -> None:
        if nidaqmx is None or AcquisitionType is None:
            raise RuntimeError(
                "nidaqmx runtime is required; install the 'nidaq' extra to enable this strategy.")

        self.all_off()
        self.data = self._build_waveforms()
        sample_rate = self.freq_hz * self.samples_per_cycle
        self.task = nidaqmx.Task()
        for ch in self.ao_channels:
            self.task.ao_channels.add_ao_voltage_chan(
    ch, min_val=-_DAQ_LIMIT, max_val=+_DAQ_LIMIT)
        self.task.timing.cfg_samp_clk_timing(  # defines buffer size
            rate=sample_rate,
            sample_mode=AcquisitionType.CONTINUOUS,
            samps_per_chan=self.samples_per_cycle,
        )
        self.task.write(self.data)
        if start:
            self.task.start()
