from __future__ import annotations

from ..fluke.fluke6105a import Fluke6105A
from .strategy import Capability, SourceStrategy


class FlukeStrategy(SourceStrategy):
    """
    Strategy wrapper around the Fluke 6105A SCPI driver.

    Notes:
    - Uses Fluke6105A.open(<VISA>) constructor inherited from SCPIInstrument.
    - Immediate-apply instrument: most setters take effect as soon as called.
    """

    def __init__(self, visa: str, *, verbose: bool = False):
        self._visa = visa
        self._verbose = bool(verbose)
        self._drv: Fluke6105A | None = None
        # Mapping from strategy phase identifiers (P1 P2 etc) to what the
        # driver wants
        self._phase_map = {'P1': 1, 'P2': 2, 'P3': 3}

    # ----- lifecycle -----
    def open(self) -> None:
        self._drv = Fluke6105A.open(self._visa, verbose=self._verbose)
        # sensible defaults
        try:
            self._drv.set_angle_units("DEG")
            self._drv.set_mhar_units("VOLT", "ABS")
            self._drv.set_mhar_units("CURR", "ABS")
            self._drv.output_enable(False)
            self.all_off()
        except Exception:
            # don't block open if any of the above fail
            pass

    def close(self) -> None:
        if self._drv is not None:
            try:
                self._drv.output_enable(False)
                self.all_off()
            except Exception:
                pass
            try:
                self._drv.close()
            finally:
                self._drv = None

    # ----- basic control -----
    def on(self) -> None:
        self._require()
        self._drv.output_enable(True)  # type: ignore[union-attr]

    def off(self) -> None:
        self._require()
        self._drv.output_enable(False)  # type: ignore[union-attr]

    def all_off(self) -> None:
        self._require()
        for p in (1, 2, 3):
            self._drv.enable_voltage(p, False)  # type: ignore[union-attr]
            self._drv.enable_current(p, False)  # type: ignore[union-attr]
            self._drv.set_voltage(p, 0.0)       # type: ignore[union-attr]
            self._drv.set_current(p, 0.0)       # type: ignore[union-attr]

    # ----- frequency & per-phase primitives -----
    def set_frequency(self, freq_hz: float) -> None:
        self._require()
        self._drv.set_frequency(freq_hz)  # type: ignore[union-attr]

    def set_phase_voltage(self, phase: str, voltage_v: float) -> None:
        self._require()
        self._drv.set_voltage(self._phase_map[phase], float(
            voltage_v))         # type: ignore[union-attr]
        self._drv.enable_voltage(
    self._phase_map[phase],
     voltage_v > 0.0)       # type: ignore[union-attr]

    def set_phase_current(self, phase: str, current_a: float) -> None:
        self._require()
        self._drv.set_current(self._phase_map[phase], float(
            current_a))         # type: ignore[union-attr]
        self._drv.enable_current(
    self._phase_map[phase],
     current_a > 0.0)       # type: ignore[union-attr]

    def set_phase_voltage_angle(self, phase: str, angle_deg: float) -> None:
        self._require()
        self._drv.set_voltage_phase(
    self._phase_map[phase],
     float(angle_deg))   # type: ignore[union-attr]

    def set_phase_current_angle(self, phase: str, angle_deg: float) -> None:
        self._require()
        self._drv.set_current_phase(
    self._phase_map[phase],
     float(angle_deg))   # type: ignore[union-attr]

    def apply(self) -> None:
        # Fluke applies immediately; keep for interface parity
        return

    # ----- convenience (for compatibility with earlier helpers) -----
    def set_phase_vfa(self, phase: str, voltage_v: float,
                      freq_hz: float, angle_deg: float) -> None:
        """Set Voltage/Frequency/Angle for a phase (Voltage angle)."""
        self.set_frequency(freq_hz)
        self.set_phase_voltage(phase, voltage_v)
        self.set_phase_voltage_angle(phase, angle_deg)

    # ----- capabilities -----
    def capabilities(self) -> set[Capability]:
        return {
            Capability.ThreePhase,
            Capability.VoltageAmplitude,
            Capability.CurrentAmplitude,
            Capability.VoltagePhaseAngle,
            Capability.CurrentPhaseAngle,
            Capability.Frequency,
            Capability.ImmediateApply,
        }

    # ----- helpers -----
    def _require(self) -> None:
        if self._drv is None:
            raise RuntimeError("FlukeStrategy not opened yet")
